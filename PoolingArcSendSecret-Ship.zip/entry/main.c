#include "entry.h"

#include "console.h"
#include "assets.h"
#include <string.h>

static void health(
    const log_request *request,
    log_response *response
) {
    if (!strcmp(request->path, "/api/echo")) {
        response->status = 200;
        response->content_type = "text/plain; charset=utf-8";
        response->body = request->body;
        response->body_length = request->body_length;
        return;
    }

    static const char json[] =
        "{\"ok\":true,\"framework\":\"PoolingArcSendSecret\"}";

    response->status = 200;
    response->content_type = "application/json; charset=utf-8";
    response->body = json;
    response->body_length = sizeof(json) - 1;
}


int main(void) {
    int result = log_console_run(log_asset_response, health);
    log_assets_free();
    return result;
}
