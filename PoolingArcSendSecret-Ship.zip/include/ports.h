#ifndef LOG_PORTS_H
#define LOG_PORTS_H
#include "pool.h"
void log_ports_open(const log_pool_config *config);
void log_ports_close(void);
void log_ports_status(void);
#endif
