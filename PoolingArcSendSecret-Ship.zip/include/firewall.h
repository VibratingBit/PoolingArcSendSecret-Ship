#ifndef LOG_FIREWALL_H
#define LOG_FIREWALL_H
#include "pool.h"
bool log_firewall_open(const log_pool_config *config, bool smtp_ready);
void log_firewall_close(void);
#endif
