#include "ports_policy.h"
#include <string.h>
int log_ports_classify(
    int result, const char *client, const char *internal,
    const char *description, const char *local, const char *port
) {
    if (result == 714) return 0;
    if (result != 0) return -3;
    if (strcmp(client, local) || strcmp(internal, port)) return -1;
    return strcmp(description, "PoolingArcSendSecret") ? 2 : 1;
}
