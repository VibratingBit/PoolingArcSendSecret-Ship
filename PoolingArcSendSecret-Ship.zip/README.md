# PoolingArcSendSecret - Institute / COG / Canvas first draft

## Build and run

1. Close the previous server. Replace the project files with this package.
   Preserve the entire Launch folder, including pool.conf, ssl, private, Mail and Media.
2. Double-click log.bat. The single scripts/build.ps1 helper checks/caches the
   existing toolchain and prebuilt static OpenSSL/MiniUPnPc dependencies, builds
   with Ninja, runs the tests and publishes Launch/PoolingArcSendSecret.exe.
   No MSYS2 environment, Perl or Make is installed. .build is removed on success.
3. The preferred PEM pair is Launch/ssl/LoveShip-chain.pem and
   Launch/ssl/LoveShip-key.pem. Existing explicit certificate paths in pool.conf
   are now preserved by log.bat. For /ssl aliases only, if BOTH Launch files are
   absent, runtime also checks project/ssl, its parent/ssl, then the Windows
   drive-root ssl folder. It uses a pair from one folder, never a mixed pair.
   An existing incomplete, unreadable or mismatched Launch pair is reported
   rather than bypassed. No self-signed certificate is silently generated.
4. Double-click the EXE and approve UAC. Browse https://your-covered-domain/.
   A numeric IP or a domain absent from the certificate SAN still produces a
   browser certificate warning; this code does not bypass certificate checks.

The build updates known public-network settings in the ONLY configuration,
Launch/pool.conf: reference domains, 0.0.0.0:80/443, SMTP on 25, firewall/UPnP
options and local diagnostic DNS 127.0.0.1:53535. Other settings persist. This
migration behavior means these known fields are reapplied on every build.
Credentials and COG data are never overwritten by the build. Back up private
before upgrading. A fresh install has no default password or member accounts.

## Create the administrator Sshhm

- After first launch, open Launch/private/institute/setup.token locally on the
  server. Do NOT share this token publicly or put it in a URL.
- Visit the site over valid HTTPS. Until the owner exists, HTML pages show only
  the Go Live card. Click it and enter your chosen password twice and the local
  setup token. The owner name is fixed as Sshhm. Use 15-128 UTF-8 bytes.
- The token is consumed after successful administrator creation. Sshhm is
  reserved; an ordinary registration cannot claim this account. Usernames are
  case-insensitive; the internal member key is `sshhm` and display name Sshhm.
- Setup signs you in immediately. Administrator controls now appear. Other
  registrations create member accounts and sign in immediately.
  The administrator can query members, assign moderator/member roles and remove
  members through /acccount (also available as /account). The primary administrator cannot be removed there.
  Membership changes revoke all sessions, so sign in again afterward.

Passwords are salted PBKDF2-HMAC-SHA256 hashes (600,000 iterations), not plaintext
or reversible SSL encryption. Every record includes its hash schema/work factor.
A host-only Secure/HttpOnly/SameSite=Strict cookie carries a random session token;
only its digest is held server-side. Sessions expire after one hour and are
revoked on restart. State-changing authorized requests require same-Origin and
an unpredictable session CSRF token. Login/register have IP/global rate limits; registration also has a honeypot
field and server-side password confirmation. These limit abuse but cannot
guarantee that all bots are blocked.
The API rejects HTTP, and the UI refuses to send credentials over HTTP. The
private credential/CMS/mail directories are restricted to the runtime Windows
account, local Administrators and SYSTEM. This is a first implementation, not an
independently audited authentication product. Password reset, email verification,
MFA and production abuse defenses remain future work.

## Real .cog data, insert/query/update/remove

- Launch/private/institute/members.cog: member records and password hashes.
- Launch/private/cms/pages.cog: route metadata and published cards.
- Launch/Mail/Sshhm/mailbox.cog: message/folder index for the owner mailbox.
- Raw messages are separate Mail/Sshhm/<folder>/<random-id>.eml files.

First-draft format (hex is encoding, NOT encryption):

    COG 1
    TABLE members
    ROW <hex-encoded-key> <hex-encoded-record-value>

Keys are unique. NULs, malformed hex, wrong table versions, duplicate keys,
oversized records and corrupted files are rejected. lib functions log_cog_put,
log_cog_get, log_cog_scan and log_cog_remove implement insertion, updates, query
and removal. Values follow application schemas; MEMBER1 records include role,
PBKDF2 work factor, salt and digest. No commands or scripts are executed from
.cog files. Writes use replacement files and native replacement on Windows.
This is a bounded single-process store: 512 rows/table, 128 KiB values, 8 MiB/file,
and 256 accounts. It is not a full SQL engine or a power-loss-tested database.
Do not edit member rows manually or expose private as a static asset directory.

## Pages, routes and cards

The top label displays the current browser domain and links to its origin.
A route row starts with /maintenance and lists created pages alphabetically.
The list refreshes periodically and on focus. Pages use extensionless URLs:
/maintenance, /Institute, /News, /Live, /Media. There is no need for .html in a URL.
Explicit /maintenance and /maintenance/ routes have parser/asset regression tests.

An administrator/moderator can Create page with a route name, heading,
description and body. It immediately becomes an extensionless page using the
shared server template; headings/descriptions are HTML-escaped. Edit page updates
its metadata. Canvas cards have a custom category/label, heading, description and
content. They are side by side; expansion spans the body. Apply card edits to a
browser draft, then Publish workspace to commit the page/cards to pages.cog for
all visitors. Existing old local drafts are not automatically published. Page
writes are server-authorized, not based on a browser role toggle. All page writes
are last-save-wins; revision/conflict management is not implemented yet.

Current template fields: {{site.title}}, {{site.tagline}}, {{site.hostname}},
{{page.heading}}, {{page.subtitle}}, {{page.description}}. Site text is configured
through site_title/site_tagline in pool.conf; page text through the CMS. Template
values are escaped text, never executable HTML. Placeholders are for HTML text
contexts, not JS/CSS/URLs/event handlers. Frontend components use <template>
cloning and textContent. CSP blocks external scripts, objects and framing.

BBCode supports [b], [i], [u], [url], [img], [video] and [audio] with closing tags.
Both [/img] and the requested [\img] are accepted. Example:

    [img] /mirror-logo.png [\img]
    [video] https://example.org/clip.mp4 [/video]

Only HTTP(S) and relative media URLs are allowed. Images/video/audio have thin
frames; click an image or Enlarge to open a larger preview. A video link must be
a directly playable media file, not a YouTube HTML page. Raw HTML/iframes and
javascript/data URLs are not interpreted. Card content grows naturally to a
460px maximum (double the original 230px baseline), then scrolls. The form's
text area auto-grows within its cap; manual resize is disabled.

The footer has a solid theme background. The old draft notice is replaced by
centered { Transaction Trail } with an ASCII canvas. Theme, accent and 8-20px
text preferences persist locally in this browser; content/publication lives in
server COG storage. Assets are index.html, maintenance.html, institute.html,
design.css, design.js, honeycomb.svg and mirror-logo.png under Launch/entry.

## Inbound SMTP on TCP 25

The optional C SMTP module is now implemented and built by default. It binds
smtp_bind/smtp_port, advertises STARTTLS, and validates the configured TLS
certificate/key. On successful startup only, firewall/UPnP adds port 25 as well
as active web ports. Set smtp_enabled false to disable; a compile-time
LOG_ENABLE_SMTP=OFF builds a disabled module stub instead.

Only Sshhm@<configured-domain> is accepted: e.g. Sshhm@lovehive.org and
Sshhm@delicacy.diy, all attached to the SAME administrator mailbox. Recipients
are deferred until Sshhm's administrator account exists. Other recipients and
relay destinations are rejected. The account password stays in the Institute
HTTPS session system: it is never exposed as an SMTP AUTH password.

Sshhm now has a private webmail interface at /Mail (also /Mail/Sshhm). All
configured Sshhm@domain aliases share the owner's mailbox. The active owner
session is required for every mailbox API, plus CSRF and same-Origin checks
for changes. No other member has an active mailbox in this draft.

Mail is stored in Launch/Mail/Sshhm with inbox, sent, archive, blocked and
outbox folders. RFC 5322 .eml files hold messages; mailbox.cog indexes them,
blocked.cog stores sender rules, and delivery.cog records outbound results.
Windows ACLs restrict these paths to the runtime user, Administrators and
SYSTEM. Files are private but are not encrypted at rest. Ordinary HTTP paths
never serve mailbox data. Existing indexed private/mail messages are moved
into the new mailbox on startup; back up the entire Launch folder first.

Incoming SMTP handles dot-stuffing, bounded lines/message sizes, a session
deadline and a 256 MiB aggregate indexed mailbox limit (500 stored messages).
Blocked senders go into Blocked rather than vanishing. You can read, archive,
move, block/unblock senders and permanently delete messages. Reader previews
show plain RFC 5322 source, capped at 128 KiB; rich MIME HTML, attachment
extraction and inline attachment rendering are not implemented.

Compose sends one recipient and plain UTF-8 text. Non-ASCII subjects are MIME
encoded. Local Sshhm aliases are delivered internally. External messages are
staged in Outbox and sent by one background Windows worker using DNS MX lookup,
IPv4/IPv6, TCP 25, STARTTLS and certificate/hostname verification using Windows
trust roots. Up to three MX hosts are tried before DATA starts. Destinations
without verified TLS are refused; there is no plaintext fallback. Only a final
250 acknowledgement moves a message to Sent. This is acceptance by the next
server, not proof of inbox placement. Failure details stay in Outbox. Retry is
manual with an ambiguity warning; no automatic retries occur after DATA begins.
Interrupted sends are marked unknown at startup. There are ten send/retry
attempts per minute. Do not delete an in-flight Outbox item.

This remains a first mail implementation: no submission 587, external SMTP
AUTH, relay-provider configuration, IMAP/POP, DKIM signing, delivery-status
notification processing, production antispam or scheduled durable retry engine.
The public SMTP listener accepts local recipients only; it is not an open relay.

Public mail delivery also needs appropriate registrar MX/A records and an ISP
that permits inbound TCP 25. UPnP cannot bypass ISP port blocking or CGNAT.
Configure MX records at your actual DNS provider; the local diagnostic DNS
service does not replace registrar nameservers or manage public MX records.

## Console and networking

Commands: help, start, shutdown, restart/reload, status, traffic, config,
ports open/status/close, logs on/off, /wipe, exit. Commands stay above the colored
scrolling log pane. Mouse wheel/PgUp/PgDn scroll logs; Ctrl+End follows live.
/wipe clears screen history, not traffic or persisted COG data. Use exit for
orderly mapping/firewall cleanup. Forced termination may leave permanent rules.

Router compatibility preserves rules already targeting this LAN host, refuses
known foreign-device mappings, logs exact UPnP errors, and can use legacy
Add-first mode when queries fail. upnp_legacy_compat=true may replace a rule
whose target could not be queried. upnp_allow_permanent=true permits fallback
on router error 725. Permanent rules have no expiry; readback failure or a crash
can prevent safe automatic cleanup. Router acceptance does NOT prove public
reachability. Test web/mail from outside your LAN and inspect the logs.

Diagnostic DNS is a local-only allowlisted A lookup service through Windows DNS
on UDP 53535. It is not a complete recursive or authoritative DNS implementation.
HTTP and SMTP are each single-worker services; general connection/rate-limit
settings are not all enforced. Public deployment needs further load/security
review, especially denial-of-service resistance and durable recovery.

## Verification

Local tests exercise COG insert/query/update/remove, account setup/login,
secure-session rejection on HTTP, Origin/CSRF checks, account roles/removal,
CMS authorization, browser-style /maintenance parsing, asset routing and SMTP
local-recipient/no-relay policy. TLS context/key matching tests also pass. JS
syntax is checked. Windows C compilation, UAC/ACL behavior, console rendering,
real browser auth/media flows and live SMTP/STARTTLS/router integration have
NOT been executed in this environment. These additions require Windows testing;
they are not presented as audited production security or full old-server parity.


## Updated navigation and editing

Institute has independent Register and Login panels. Login needs username and
password; registration also requires password confirmation. After success the
browser returns to the last safe page visited in that tab. Active sessions are
redirected away from Institute. The identity button becomes your username and
opens /acccount; Logout replaces the account access buttons. Password changes
require the current password and revoke every session.

Route tabs wrap below the compact header, next to the identity button. Create
page is in the footer at the right. Create card, Publish workspace and Edit page
are grouped together. Maintenance permits administrator/moderator custom cards
after the built-in diagnostic cards, but has no Create page control.

Card editors offer Book, Canvas, Rabbit and Star characters, descriptive
Label | Value boxes and an optional action link. BBCode tools cover b/i/u,
code, quote, image, video, link and smiley symbols. Code blocks have dotted
borders, quotes dashed borders, and media previews show their filenames.
Relative and absolute HTTP(S) media paths are accepted; only explicitly served
assets/routes are available on this server. Form widths stay within their
dialogs; text areas grow to twice their baseline height, then scroll.

Verification: portable C tests and JavaScript syntax checks were run in the
Linux development environment. Windows compilation, real-browser layout and
public-domain SMTP/TLS integration still require testing on your Windows host.


## Media and appearance update

Text size now loads all 8-20 px options, remembers a valid selection and falls
back to 13 px when storage is unavailable or the saved value is invalid. The
main heading artwork is the rabbit again; the workspace character choices remain
Book/Canvas/Rabbit/Star. Media sits beside Text size on the left. Published card
controls say Edit and Delete. Page Body fields use solid borders with a bottom
left peel and top right peel; the signed-in identity is bold.

Place supported media directly in Launch/Media. log.bat copies Media/index.html
without deleting other media. /Media, /Media/ and /Media/index.html open the
gallery. JPG/JPEG, PNG, GIF, WebP, AVIF, MP4, WebM, OGV, MP3, OGG, WAV, FLAC
and M4A files have previews, filename footers and enlargement controls; audio
also has Play/Pause. Browser codec support varies. Listings are bounded to 500
files and files to 64 MiB. Subfolders, symbolic links/reparse files and executable
formats are excluded. Single HTTP byte ranges allow seeking in audio/video.

Portable regression tests cover dropdown population/persistence, media listing,
byte ranges, traversal rejection, mailbox authorization checks, local delivery,
folder moves, sender blocking and existing account/CMS tests. Windows compilation,
background direct-MX delivery and real browser layout were not run here. Chromium
is missing from this development environment. See RFC 5321 for MX routing and
OpenSSL SSL_set1_host/SSL_CTX_set_verify for destination TLS verification.


## TLS startup repair

The previous generic "Check bind/port" message could follow a certificate-file
failure. Startup now identifies the exact certificate/key path and whether it
could not be read, parsed as PEM, unlocked or matched. OpenSSL errors are cleared
before loading so stale errors do not hide the real failure. Encrypted PEM keys
fail without waiting for a hidden console prompt. HTTPS remains required when
configured; a TLS failure does not silently enable unprotected account access.

log.bat preserves existing https_certificate/https_private_key values, creates
Launch/ssl and reports missing files or an existing matching-location pair.
Private certificates/keys are not included in the source ZIP and are not copied
between folders. If no pair exists in the supported locations, put your existing
real files in Launch/ssl or configure both complete paths in Launch/pool.conf,
then use restart in the server console.

Regression tests exercise a parent ssl directory, a partial Launch pair, a
mismatched key, an encrypted key without prompting and stale OpenSSL errors.
These tests passed on the development host; the Windows startup path still
needs verification on your host with your own certificate files.


## Drop-in 0.1.4 startup fix

The supplied project archive had an empty Launch/ssl directory and contained no
PEM certificate or private key files. Unit tests generate temporary test keys;
passing those tests does not establish that the real runtime files exist.

HTTP port 80 now starts even if HTTPS certificate loading fails. HTTPS and SMTP
stay offline until real matching PEM files are present; account, setup and mail
APIs still refuse HTTP. Go Live explains the missing TLS requirement instead of
redirecting to a dead HTTPS listener. Firewall/UPnP use actual listening ports,
including when the ports open command is entered. Missing TLS never maps 443/25
as though they were running. The status command reports HTTP, HTTPS and SMTP.

Close the old server with exit before building. log.bat refuses to replace a
locked EXE and clearly reports that an old EXE was not updated. The console
header now shows 0.1.4 so old pinned or copied binaries can be identified.
The build also checks Launch/pool.conf against the REAL certificate/key pair
and saves the result in Launch/tls-check.log. A missing pair is a warning, not a
C compilation failure. Private keys are neither invented nor bundled.

Extract this ZIP directly into the existing project root, replacing source
files. Keep your existing Launch data; it is not included in this ZIP. Run
log.bat, then Launch/PoolingArcSendSecret.exe. Visit http://localhost/ to test
HTTP. To enable HTTPS and Go Live, supply your real LoveShip-chain.pem and
LoveShip-key.pem in Launch/ssl (or configure both existing paths in pool.conf),
then enter restart. Do not substitute the temporary certificates used by tests.

The FIONBIO arguments now explicitly convert the Winsock command constant to
its required signed long type, removing the two reported sign-conversion
warnings. Media/index.html is also included; it was absent in the supplied ZIP.


## LoveShip certificate correction (0.1.5)

The supplied chain has three certificates and its leaf public key matches the
supplied LoveShip-key.pem. Use LoveShip-chain.pem as https_certificate and
LoveShip-key.pem as https_private_key. LoveShip.pem is the individual leaf;
keep it if needed, but the TLS listener uses the complete chain.

log.bat automatically replaces the old /ssl/LoveVessel-* default names in the
existing Launch/pool.conf. It preserves other custom certificate paths.
The preferred locations are Launch/ssl/LoveShip-chain.pem and
Launch/ssl/LoveShip-key.pem, matching the attached archive. If both are instead
in the source project root as shown in the screenshot, the build configures
../LoveShip-chain.pem and ../LoveShip-key.pem relative to Launch. Runtime also
recognizes that root pair when /ssl aliases are configured. It never mixes a
partial Launch pair with a key from another folder.

Close the server with exit, extract this update directly into the existing
project root, and run log.bat. Keep all existing PEM files and Launch data in
place. The update does not contain private keys. The build's real-file TLS probe
checks the active pair; its result is saved in Launch/tls-check.log. This pair
also supplies STARTTLS on the optional SMTP listener.
