#ifndef LOG_TEMPLATE_H
#define LOG_TEMPLATE_H
#include <stddef.h>

typedef struct {
    const char *name;
    const char *value;
} log_template_value;

/* {{name}} expands escaped text, never executable markup. Use placeholders
   in HTML text nodes, not CSS/JS/URLs/event handlers. No raw-HTML mode. */
int log_template_render(
    const char *source,
    size_t length,
    const log_template_value *values,
    size_t count,
    char **output,
    size_t *output_length
);
#endif
