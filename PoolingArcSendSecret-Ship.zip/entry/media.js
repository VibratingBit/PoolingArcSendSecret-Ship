'use strict';
(() => {
  if (document.body.dataset.page !== 'media') return;
  const $ = id => document.getElementById(id);
  async function load() {
    try {
      const response = await fetch('/api/media', {cache:'no-store'});
      if (!response.ok) throw new Error(`Media listing: HTTP ${response.status}`);
      const files = await response.json();
      files.sort((a,b) => a.name.localeCompare(b.name));
      $('media-grid').replaceChildren(...files.map(file => {
        const article = document.createElement('article');
        article.className = 'media-tile';
        const type = file.type.split('/')[0];
        const media = document.createElement(type === 'image' ? 'img' : type);
        media.src = `/Media/file?name=${encodeURIComponent(file.name)}`;
        if (type === 'image') {
          media.alt = file.name; media.loading = 'lazy';
        } else {
          media.preload = 'none'; media.controls = true;
        }
        const preview = document.createElement('div');
        preview.className = 'media-tile-preview'; preview.append(media);
        const footer = document.createElement('div'); footer.className = 'media-tile-footer';
        const name = document.createElement('strong'); name.textContent = file.name;
        const enlarge = document.createElement('button'); enlarge.type = 'button';
        enlarge.textContent = 'Enlarge';
        enlarge.addEventListener('click', () => {
          if (type !== 'image') media.pause();
          const expanded = media.cloneNode(true);
          if (type !== 'image') expanded.controls = true;
          $('gallery-preview').replaceChildren(expanded);
          $('gallery-name').textContent = file.name;
          $('gallery-viewer').showModal();
        });
        if (type === 'image') {
          const open = document.createElement('button');
          open.type = 'button'; open.className = 'image-open';
          open.setAttribute('aria-label', `Enlarge ${file.name}`);
          open.append(media); preview.replaceChildren(open);
          open.addEventListener('click', () => enlarge.click());
        }
        footer.append(name, enlarge);
        if (type === 'audio') {
          const play = document.createElement('button'); play.type = 'button';
          play.textContent = '▶ Play';
          play.addEventListener('click', async () => {
            try { if (media.paused) await media.play(); else media.pause(); }
            catch { $('media-status').textContent = `Cannot play ${file.name} in this browser.`; }
          });
          media.addEventListener('play', () => { play.textContent = 'Ⅱ Pause'; });
          media.addEventListener('pause', () => { play.textContent = '▶ Play'; });
          footer.append(play);
        }
        article.append(preview, footer); return article;
      }));
      $('media-status').textContent = files.length
        ? `${files.length} media files` : 'Add images, videos or music to Launch\\Media, then reload.';
    } catch (error) { $('media-status').textContent = String(error); }
  }
  $('gallery-close').addEventListener('click', () => $('gallery-viewer').close());
  $('gallery-viewer').addEventListener('close', () => {
    $('gallery-preview').querySelectorAll('audio,video').forEach(media => media.pause());
    $('gallery-preview').replaceChildren();
  });
  if (window.poolReady) load();
  else window.addEventListener('pool-ready', load, {once:true});
})();
