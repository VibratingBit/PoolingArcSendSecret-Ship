#ifndef LOG_TLS_H
#define LOG_TLS_H

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#else
/* Keep cryptographic context tests independent of the Windows listener. */
#include <sys/socket.h>
typedef int SOCKET;
#endif
#include <openssl/ssl.h>

int log_tls_resolve_path(const char *source, char *output, size_t capacity);
SSL_CTX *log_tls_context(const char *certificate, const char *key);
int log_stream_receive(SOCKET socket_handle, SSL *tls, char *data, int size);
int log_stream_send(SOCKET socket_handle, SSL *tls, const char *data, int size);
int log_tls_accept(SSL *tls, const char *peer);
const char *log_tls_version(void);

#endif
