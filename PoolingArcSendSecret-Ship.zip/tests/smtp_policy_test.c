#include "smtp_policy.h"
#include <assert.h>
#include <string.h>
int main(void){
    log_pool_config c={0};strcpy(c.hostname,"delicacy.diy");
    strcpy(c.domains[c.domain_count++],"lovehive.org");
    assert(log_smtp_recipient(&c,"Sshhm@lovehive.org"));
    assert(log_smtp_recipient(&c,"Sshhm@delicacy.diy"));
    assert(!log_smtp_recipient(&c,"other@lovehive.org"));
    assert(!log_smtp_recipient(&c,"Sshhm@evil.invalid"));
    char address[256];
    assert(log_smtp_address("<sender@example.org>",address,sizeof(address)));
    assert(!log_smtp_address("<a@b>\r\nRCPT TO:<x@y>",address,sizeof(address)));
    return 0;
}
