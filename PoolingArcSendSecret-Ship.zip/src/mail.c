#include "mail.h"
#include "cog.h"
#include "form.h"
#include "store.h"
#include "institute.h"
#include "smtp_policy.h"
#include "json.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
#include <openssl/rand.h>
#include <openssl/evp.h>
#include <errno.h>
#include <ctype.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MAIL_QUOTA 268435456ULL
static atomic_flag mailbox_lock = ATOMIC_FLAG_INIT;
static log_pool_config settings;
static char reply_buffer[1048576];
static char message_buffer[131073];
static void lock(void) {
    while (atomic_flag_test_and_set(&mailbox_lock)) {
    }
}
static void unlock(void) {
    atomic_flag_clear(&mailbox_lock);
}
void log_mail_configure(const log_pool_config *config) {
    settings = *config;
}
static bool import_legacy(void);
static int recover_delivery(const char *id,const char *value,void *unused) {
    (void)unused;
    if(strcmp(value,"Sending…")) return 0;
    return log_cog_put("Mail/Sshhm/delivery.cog","delivery",id, "Interrupted at restart; delivery unknown. Check before resending.",
    false);
}
bool log_mail_init(void) {
    return log_store_prepare() && import_legacy() && !log_cog_scan("Mail/Sshhm/delivery.cog",
    "delivery",recover_delivery,NULL);
}
bool log_mail_address(const char *text) {
    size_t length = strlen(text);
    if (length < 3 || length > 254 || text[0] == '.' || text[length - 1] == '.') return false;
    const char *at = strchr(text, '@');
    if (!at || at == text || !at[1] || strchr(at + 1, '@')) return false;
    for (const unsigned char *p = (const unsigned char *)text; *p; ++p) {
        if (!isalnum(*p) && !strchr(".@_+-", *p)) return false;
    }
    return !strstr(text, "..");
}
static bool identifier(const char *id) {
    if (strlen(id) != 32) return false;
    for (unsigned i = 0; i < 32; ++i) if (!strchr("0123456789abcdef", id[i])) return false;
    return true;
}
static bool folder_name(const char *name) {
    return !strcmp(name, "inbox") || !strcmp(name, "sent") || !strcmp(name, "archive") || !strcmp(name,
    "blocked") || !strcmp(name, "outbox");
}
static bool new_id(char id[33]) {
    unsigned char bytes[16];
    if (RAND_bytes(bytes, sizeof(bytes)) != 1) return false;
    for (unsigned i = 0; i < 16; ++i) snprintf(id + i * 2, 3, "%02x", bytes[i]);
    return true;
}
static void path_for(char path[128], const char *folder, const char *id) {
    snprintf(path, 128, "Mail/Sshhm/%s/%s.eml", folder, id);
}
static bool record_fields(const char *record, size_t *bytes, char from[256], char to[256],
char path[128], char folder[16]) {
    unsigned long long size;
    if (sscanf(record, "%llu\t%255[^\t]\t%255[^\t]\t%127s", &size, from, to, path) != 4 || size > MAIL_QUOTA) return false;
    if (strncmp(path, "Mail/Sshhm/", 11)) return false;
    const char *slash = strchr(path + 11, '/');
    if (!slash || (size_t)(slash - path - 11) >= 16) return false;
    memcpy(folder, path + 11, (size_t)(slash - path - 11));
    folder[slash - path - 11] = 0;
    char id[33];
    if (strlen(slash + 1) != 36 || strcmp(slash + 33, ".eml")) return false;
    memcpy(id, slash + 1, 32);
    id[32] = 0;
    if (!identifier(id) || !folder_name(folder)) return false;
    *bytes = (size_t)size;
    return true;
}
typedef struct {
    unsigned count;
    unsigned long long bytes;
}
quota;
static int count_message(const char *key, const char *value, void *context) {
    quota *total = context;
    char from[256], to[256], path[128], folder[16];
    size_t bytes;
    if (!identifier(key) || !record_fields(value, &bytes, from, to, path, folder)) return -1;
    ++total->count;
    total->bytes += bytes;
    return total->bytes > MAIL_QUOTA ? -1 : 0;
}
static bool blocked(const char *from) {
    char lower[256], value[8];
    snprintf(lower, sizeof(lower), "%s", from);
    for (char *p = lower; *p; ++p) *p = (char)tolower((unsigned char)*p);
    return !log_cog_get("Mail/Sshhm/blocked.cog", "blocked", lower, value, sizeof(value));
}
bool log_mail_commit(const char *id, size_t size, const char *from, const char *to,
const char *path) {
    if (!identifier(id) || (from[0] && !log_mail_address(from)) || !log_mail_address(to)) return false;
    char expected[128];
    path_for(expected, "inbox", id);
    if (strcmp(path, expected)) return false;
    lock();
    quota total = {
        0
    };
    bool ok = !log_cog_scan(LOG_MAIL_INDEX, "messages", count_message, &total) && total.count < 500 && total.bytes + size <= MAIL_QUOTA;
    char target[128];
    path_for(target, blocked(from) ? "blocked" : "inbox", id);
    bool moved = false;
    if (ok && strcmp(path, target)) {
        ok = !log_store_replace(path, target);
        moved = ok;
    }
    char record[800];
    /* Empty SMTP reverse-path is recorded as <> for a stable COG field. */ snprintf(record,
    sizeof(record), "%zu\t%s\t%s\t%s", size, *from ? from : "<>", to, target);
    if (ok) ok = !log_cog_put(LOG_MAIL_INDEX, "messages", id, record, true);
    if (!ok && moved) log_store_replace(target, path);
    unlock();
    return ok;
}
bool log_mail_deliver(const char *from, const char *to, const char *message, size_t length,
char id[33]) {
    if (!new_id(id)) return false;
    char path[128], temporary[140];
    path_for(path, "inbox", id);
    snprintf(temporary, sizeof(temporary), "%s.tmp", path);
    FILE *file = fopen(temporary, "wb");
    if (!file) return false;
    bool ok = fwrite(message, 1, length, file) == length;
    if (fclose(file)) ok = false;
    if (ok) ok = !log_store_replace(temporary, path);
    if (ok) ok = log_mail_commit(id, length, from, to, path);
    if (!ok) {
        remove(temporary);
        remove(path);
    }
    return ok;
}
static int import_message(const char *id,const char *value,void *unused) {
    (void)unused;
    if (!identifier(id) || strlen(value)>=800) return -1;
    char existing[800];
    if (!log_cog_get(LOG_MAIL_INDEX,"messages",id,existing,sizeof(existing))) return log_cog_remove("private/mail/messages.cog",
    "messages",id);
    char record[800];
    strcpy(record,value);
    char *from=strchr(record,'\t');
    if (!from) return -1;
    *from++=0;
    char *to=strchr(from,'\t');
    if (!to) return -1;
    *to++=0;
    char *old=strchr(to,'\t');
    if (!old) return -1;
    *old++=0;
    char expected[128];
    snprintf(expected,sizeof(expected),"private/mail/%s.eml",id);
    char *end=NULL;
    errno=0;
    unsigned long long bytes=strtoull(record,&end,10);
    if (errno || !*record || *end || bytes>MAIL_QUOTA || strcmp(old,expected)) return -1;
    char target[128];
    path_for(target,"inbox",id);
    if (log_store_replace(old,target)) return -1;
    if (!log_mail_commit(id,(size_t)bytes,!strcmp(from,"<>")?"":from,to,target)) {
        log_store_replace(target,old);
        return -1;
    }
    return log_cog_remove("private/mail/messages.cog","messages",id);
}
static bool import_legacy(void) {
    return !log_cog_scan("private/mail/messages.cog","messages",import_message,
    NULL);
}
static void response(log_response *out, int status, const char *text) {
    out->status = status;
    out->content_type = "application/json; charset=utf-8";
    out->body = text;
    out->body_length = strlen(text);
}
static bool move_message(const char *id, const char *destination) {
    if (!identifier(id) || !folder_name(destination)) return false;
    char record[800], from[256], to[256], path[128], folder[16];
    size_t bytes;
    if (log_cog_get(LOG_MAIL_INDEX, "messages", id, record, sizeof(record)) || !record_fields(record,
    &bytes, from, to, path, folder)) return false;
    if (!strcmp(folder, destination)) return true;
    /* Sent is a delivery outcome, never a user-selected folder. */ char target[128];
    path_for(target, destination, id);
    if (log_store_replace(path, target)) return false;
    snprintf(record, sizeof(record), "%zu\t%s\t%s\t%s", bytes, from, to, target);
    if (log_cog_put(LOG_MAIL_INDEX, "messages", id, record, false)) {
        log_store_replace(target, path);
        return false;
    }
    return true;
}
#ifdef _WIN32
static atomic_bool delivery_busy;
typedef struct {
    char id[33];
    char from[256];
    char to[256];
    char *message;
}
mail_job;
static DWORD WINAPI deliver_job(void *argument) {
    mail_job *job = argument;
    char error[256] = "Delivery failed; retained in Outbox. No automatic retry.";
    bool accepted = log_mail_transport(strchr(job->from,'@')+1, job->from,job->to,
    job->message,error,sizeof(error));
    lock();
    if (accepted && !move_message(job->id,"sent")) snprintf(error,sizeof(error),
    "Destination accepted mail but Sent index failed. Do not resend.");
    else if (accepted) snprintf(error,sizeof(error),"Destination accepted message.");
    log_cog_put("Mail/Sshhm/delivery.cog","delivery",job->id,error,false);
    unlock();
    free(job->message);
    free(job);
    atomic_store(&delivery_busy,false);
    return 0;
}
static bool schedule_delivery(const char *id,const char *from,const char *to,
char *message) {
    bool expected = false;
    if (!atomic_compare_exchange_strong(&delivery_busy,&expected,true)) return false;
    mail_job *job = calloc(1,sizeof(*job));
    if (!job) {
        atomic_store(&delivery_busy,false);
        return false;
    }
    strcpy(job->id,id);
    strcpy(job->from,from);
    strcpy(job->to,to);
    job->message = message;
    lock();
    int recorded=log_cog_put("Mail/Sshhm/delivery.cog","delivery",id,"Sending…",false);
    unlock();
    if(recorded) { free(job); atomic_store(&delivery_busy,false); return false; }
    HANDLE worker = CreateThread(NULL,0,deliver_job,job,0,NULL);
    if (!worker) {
        lock();
        log_cog_put("Mail/Sshhm/delivery.cog","delivery",id,
            "Worker failed to start; retained in Outbox.",false);
        unlock();
        free(job);
        atomic_store(&delivery_busy,false);
        return false;
    }
    CloseHandle(worker);
    return true;
}
#endif
static void subject_for(const char *path, char subject[256]) {
    subject[0] = 0;
    FILE *file = fopen(path, "rb");
    if (!file) return;
    char line[1001];
    unsigned lines = 0;
    while (lines++ < 100 && fgets(line, sizeof(line), file)) {
        if (!strcmp(line, "\r\n") || !strcmp(line, "\n")) break;
        char key[9];
        for (unsigned i = 0; i < 8; ++i) key[i] = (char)tolower((unsigned char)(strlen(line) > i ? line[i] : 0));
        key[8] = 0;
        if (!strcmp(key, "subject:")) {
            const char *begin = line + 8;
            while (*begin == ' ' || *begin == '\t') ++begin;
            snprintf(subject, 256, "%.255s", begin);
            subject[strcspn(subject, "\r\n")] = 0;
            break;
        }
    }
    fclose(file);
}
typedef struct {
    log_json *json;
    const char *folder;
    unsigned count;
}
list_context;
static int list_message(const char *id, const char *record, void *context) {
    list_context *list = context;
    char from[256], to[256], path[128], folder[16], subject[256];
    size_t bytes;
    if (!record_fields(record, &bytes, from, to, path, folder)) return -1;
    if (strcmp(folder, list->folder)) return 0;
    subject_for(path, subject);
    if (list->count++) log_json_text(list->json, ",");
    log_json_text(list->json, "{\"id\":");
    log_json_string(list->json, id);
    log_json_text(list->json, ",\"from\":");
    log_json_string(list->json, from);
    log_json_text(list->json, ",\"to\":");
    log_json_string(list->json, to);
    log_json_text(list->json, ",\"subject\":");
    log_json_string(list->json, subject);
    char size[64];
    snprintf(size, sizeof(size), ",\"size\":%zu", bytes);
    log_json_text(list->json, size);
    char delivery[256] = "";
    log_cog_get("Mail/Sshhm/delivery.cog","delivery",id,delivery,sizeof(delivery));
    log_json_text(list->json,",\"delivery\":");
    log_json_string(list->json,delivery);
    log_json_text(list->json,"}");
    return list->json->failed ? -1 : 0;
}
static int list_blocked(const char *key, const char *value, void *context) {
    (void)value;
    list_context *list = context;
    if (list->count++) log_json_text(list->json, ",");
    log_json_string(list->json, key);
    return list->json->failed ? -1 : 0;
}
static bool encode_subject(const char *text,char output[1024]) {
    bool high=false;
    for (const unsigned char *p=(const unsigned char *)text;*p;++p) {
        if (*p<32 || *p==127) return false;
        high |= *p>127;
    }
    if (!high) {
        snprintf(output,1024,"%s",text);
        return true;
    }
    size_t used=0;
    const unsigned char *p=(const unsigned char *)text;
    while (*p) {
        size_t remaining=strlen((const char *)p);
        size_t count=remaining>42?42:remaining;
        if (count<remaining) while (count && (p[count]&0xc0)==0x80) --count;
        if (!count) return false;
        unsigned char base64[65];
        EVP_EncodeBlock(base64,p,(int)count);
        int wrote=snprintf(output+used,1024-used,"%s=?UTF-8?B?%s?=", used?"\r\n ":"",
        (const char *)base64);
        if (wrote<0 || (size_t)wrote>=1024-used) return false;
        used+=(size_t)wrote;
        p+=count;
    }
    return true;
}
static bool compose(const char *from, const char *to, const char *subject, const char *text,
char **output) {
    char encoded[1024];
    if (!encode_subject(subject,encoded)) return false;
    char id[33];
    if (!new_id(id)) return false;
    size_t capacity = strlen(text) * 2 + 4096;
    char *message = malloc(capacity);
    if (!message) return false;
    time_t now = time(NULL);
    struct tm *utc = gmtime(&now);
    char date[80];
    if (!utc || !strftime(date, sizeof(date), "%a, %d %b %Y %H:%M:%S +0000", utc)) {
        free(message);
        return false;
    }
    int length = snprintf(message, capacity, "Date: %s\r\nMessage-ID: <%s@%s>\r\nFrom: <%s>\r\nTo: <%s>\r\n" "Subject: %s\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n" "Content-Transfer-Encoding: 8bit\r\n\r\n",
    date, id, strchr(from, '@') + 1, from, to, encoded);
    if (length < 0 || (size_t)length >= capacity) {
        free(message);
        return false;
    }
    size_t used = (size_t)length;
    unsigned column = 0;
    for (const char *p = text; *p; ++p) {
        if (*p == '\r') continue;
        if (*p == '\n' || column == 900) {
            message[used++] = '\r';
            message[used++] = '\n';
            column = 0;
            if (*p == '\n') continue;
        }
        message[used++] = *p;
        ++column;
    }
    message[used++] = '\r';
    message[used++] = '\n';
    message[used] = 0;
    *output = message;
    return true;
}
bool log_mail_handle(const log_request *r, log_response *out) {
    if (strcmp(r->path, "/api/mail") && strcmp(r->path, "/api/mail/status") && strcmp(r->path,
    "/api/mail/blocked")) return false;
    if (!r->secure || log_institute_role(r, false) != 3) {
        response(out, 403, "{\"error\":\"Sshhm HTTPS session required\"}");
        return true;
    }
    if (!strcmp(r->method, "GET")) {
        log_json json = {
            reply_buffer, 0, sizeof(reply_buffer), false
        };
        if (!strcmp(r->path, "/api/mail/status")) {
            log_json_text(&json, "{\"addresses\":[");
            char address[272];
            snprintf(address, sizeof(address), "Sshhm@%s", settings.hostname);
            log_json_string(&json, address);
            for (unsigned i = 0; i < settings.domain_count; ++i) {
                snprintf(address, sizeof(address), "Sshhm@%s", settings.domains[i]);
                log_json_text(&json, ",");
                log_json_string(&json, address);
            }
            bool enabled=settings.smtp_enabled!=0;
#if defined(LOG_WITH_SMTP) && !LOG_WITH_SMTP
            enabled=false;
#endif
            log_json_text(&json, enabled ? "],\"smtp\":true}" : "],\"smtp\":false}");
        }
        else if (!strcmp(r->path, "/api/mail/blocked")) {
            list_context list = {
                &json, "", 0
            };
            log_json_text(&json, "[");
            lock();
            int result = log_cog_scan("Mail/Sshhm/blocked.cog", "blocked", list_blocked,
            &list);
            unlock();
            if (result) json.failed = true;
            log_json_text(&json, "]");
        }
        else {
            char id[33];
            if (!log_form_get(r->query, strlen(r->query), "id", id, sizeof(id))) {
                char record[800], from[256], to[256], path[128], folder[16];
                size_t bytes;
                lock();
                bool ok = identifier(id) && !log_cog_get(LOG_MAIL_INDEX, "messages",
                id, record, sizeof(record)) && record_fields(record, &bytes, from,
                to, path, folder);
                FILE *file = ok ? fopen(path, "rb") : NULL;
                size_t length = file ? fread(message_buffer, 1, sizeof(message_buffer) - 1,
                file) : 0;
                if (file) fclose(file);
                unlock();
                if (!file) {
                    response(out, 404, "{\"error\":\"Message not found\"}");
                    return true;
                }
                message_buffer[length] = 0;
                log_json_text(&json, "{\"text\":");
                log_json_string(&json, message_buffer);
                log_json_text(&json, bytes > length ? ",\"truncated\":true}" : ",\"truncated\":false}");
            }
            else {
                char folder[16] = "inbox";
                if (log_form_get(r->query, strlen(r->query), "folder", folder,
                sizeof(folder))) strcpy(folder,"inbox");
                if (!folder_name(folder)) {
                    response(out, 400, "{}");
                    return true;
                }
                list_context list = {
                    &json, folder, 0
                };
                log_json_text(&json, "[");
                lock();
                int result = log_cog_scan(LOG_MAIL_INDEX, "messages", list_message,
                &list);
                unlock();
                if (result) json.failed = true;
                log_json_text(&json, "]");
            }
        }
        response(out, json.failed ? 500 : 200, json.failed ? "{\"error\":\"Mailbox read failed\"}" : reply_buffer);
        return true;
    }
    if (strcmp(r->method, "POST")) {
        response(out, 405, "{}");
        return true;
    }
    if (log_institute_role(r, true) != 3) {
        response(out, 403, "{\"error\":\"CSRF rejected\"}");
        return true;
    }
    char action[16];
    if (log_form_get(r->body, r->body_length, "action", action, sizeof(action))) {
        response(out, 400, "{}");
        return true;
    }
    if (!strcmp(action, "block") || !strcmp(action, "unblock")) {
        char address[256];
        if (log_form_get(r->body, r->body_length, "address", address, sizeof(address)) || !log_mail_address(address)) {
            response(out, 400, "{}");
            return true;
        }
        for (char *p = address; *p; ++p) *p = (char)tolower((unsigned char)*p);
        lock();
        int result = !strcmp(action, "block") ? log_cog_put("Mail/Sshhm/blocked.cog",
        "blocked", address, "1", false) : log_cog_remove("Mail/Sshhm/blocked.cog",
        "blocked", address);
        unlock();
        response(out, result ? 400 : 200, result ? "{\"error\":\"Block list update failed\"}" : "{\"ok\":true}");
        return true;
    }
    if (!strcmp(action,"delete")) {
        char id[33],record[800],from[256],to[256],path[128],folder[16];
        size_t bytes;
        bool valid=!log_form_get(r->body,r->body_length,"id",id,sizeof(id)) && identifier(id);
        lock();
        valid=valid && !log_cog_get(LOG_MAIL_INDEX,"messages",id,record,sizeof(record)) && record_fields(record,
        &bytes,from,to,path,folder);
#ifdef _WIN32
        if(valid && !strcmp(folder,"outbox") && atomic_load(&delivery_busy)) valid=false;
#endif
        if(valid) {
            valid=!log_cog_remove(LOG_MAIL_INDEX,"messages",id);
            if(valid && remove(path)) {
                log_cog_put(LOG_MAIL_INDEX,"messages",id,record,false);
                valid=false;
            }
            if(valid) log_cog_remove("Mail/Sshhm/delivery.cog","delivery",id);
        }
        unlock();
        response(out,valid?200:400,valid?"{\"ok\":true}":"{\"error\":\"Delete failed or sender busy\"}");
        return true;
    }
    if (!strcmp(action, "move")) {
        char id[33], folder[16];
        bool valid = !log_form_get(r->body, r->body_length, "id", id, sizeof(id)) && !log_form_get(r->body,
        r->body_length, "folder", folder, sizeof(folder)) && (!strcmp(folder,
        "inbox") || !strcmp(folder, "archive") || !strcmp(folder, "blocked"));
        lock();
#ifdef _WIN32
        if(valid && atomic_load(&delivery_busy)) {
            char record[800],from[256],to[256],path[128],current[16]; size_t bytes;
            valid=!log_cog_get(LOG_MAIL_INDEX,"messages",id,record,sizeof(record)) &&
                record_fields(record,&bytes,from,to,path,current) && strcmp(current,"outbox");
        }
#endif
        bool ok = valid && move_message(id, folder);
        unlock();
        response(out, ok ? 200 : 400, ok ? "{\"ok\":true}" : "{\"error\":\"Move failed\"}");
        return true;
    }
    if (!strcmp(action,"send") || !strcmp(action,"retry")) {
#if defined(LOG_WITH_SMTP) && !LOG_WITH_SMTP
        response(out,503,"{\"error\":\"SMTP module was not compiled\"}");
        return true;
#endif
        if(!settings.smtp_enabled) {
            response(out,503,"{\"error\":\"SMTP disabled\"}");
            return true;
        }
        static time_t window;
        static unsigned sent;
        time_t now = time(NULL);
        if (now - window >= 60) {
            window = now;
            sent = 0;
        }
        if (++sent > 10) {
            response(out, 429, "{\"error\":\"Ten send attempts per minute maximum\"}");
            return true;
        }
    }
    if (!strcmp(action,"retry")) {
#ifdef _WIN32
        char id[33],record[800],from[256],to[256],path[128],folder[16];
        size_t bytes;
        bool valid=!log_form_get(r->body,r->body_length,"id",id,sizeof(id)) && identifier(id);
        lock();
        valid=valid && !log_cog_get(LOG_MAIL_INDEX,"messages",id,record,sizeof(record)) && record_fields(record,
        &bytes,from,to,path,folder) && !strcmp(folder,"outbox") && bytes<=131072 && log_smtp_recipient(&settings,
        from) && log_mail_address(to);
        char *message=valid?malloc(bytes+1):NULL;
        FILE *file=message?fopen(path,"rb"):NULL;
        valid=file && fread(message,1,bytes,file)==bytes;
        if(file) fclose(file);
        if(valid) message[bytes]=0;
        unlock();
        if(!valid) {
            free(message);
            response(out,400,"{\"error\":\"Outbox message unavailable\"}");
            return true;
        }
        if(!settings.smtp_enabled || !schedule_delivery(id,from,to,message)) {
            free(message);
            response(out,503,"{\"error\":\"Sender disabled or busy\"}");
            return true;
        }
        response(out,202,"{\"queued\":true,\"message\":\"Retry started. Check Outbox or Sent.\"}");
#else
        response(out,501,"{\"error\":\"Windows delivery required\"}");
#endif
        return true;
    }
    if (strcmp(action, "send")) {
        response(out, 400, "{}");
        return true;
    }
#if defined(LOG_WITH_SMTP) && !LOG_WITH_SMTP
    response(out,503,"{\"error\":\"SMTP module was not compiled\"}");
    return true;
#endif
    if (!settings.smtp_enabled) {
        response(out, 503, "{\"error\":\"SMTP module disabled\"}");
        return true;
    }
    char from[256], to[256], subject[256], text[64001];
    if (log_form_get(r->body, r->body_length, "from", from, sizeof(from)) || log_form_get(r->body,
    r->body_length, "to", to, sizeof(to)) || log_form_get(r->body, r->body_length,
    "subject", subject, sizeof(subject)) || log_form_get(r->body, r->body_length,
    "text", text, sizeof(text)) || !log_mail_address(from) || !log_mail_address(to) || !log_smtp_recipient(&settings,
    from)) {
        response(out, 400, "{\"error\":\"Invalid envelope or fields\"}");
        return true;
    }
    char *message = NULL;
    if (!compose(from, to, subject, text, &message)) {
        response(out, 400, "{}");
        return true;
    }
    char id[33];
    bool saved = log_mail_deliver(from, to, message, strlen(message), id);
    if (!saved) {
        free(message);
        response(out, 507, "{\"error\":\"Mailbox storage failed\"}");
        return true;
    }
    lock();
    bool staged = move_message(id, "outbox");
    unlock();
    if (!staged) {
        free(message);
        response(out, 500, "{\"error\":\"Could not stage mail\"}");
        return true;
    }
#ifdef _WIN32
    if (!log_smtp_recipient(&settings,to)) {
        lock();
        log_cog_put("Mail/Sshhm/delivery.cog","delivery",id,"Sending…",false);
        unlock();
        if (schedule_delivery(id,from,to,message)) {
            response(out,202,"{\"queued\":true,\"message\":\"Sending in background. Check Outbox or Sent.\"}");
        }
        else {
            free(message);
            lock();
            log_cog_put("Mail/Sshhm/delivery.cog","delivery",id,"Sender busy; retained in Outbox. Not sent.",
            false);
            unlock();
            response(out,503,"{\"error\":\"Sender busy; message saved in Outbox. Not sent.\"}");
        }
        return true;
    }
#endif
    char error[256] = "Destination did not accept the message";
    bool delivered;
    if (log_smtp_recipient(&settings, to)) {
        char inbound[33];
        delivered = log_mail_deliver(from, to, message, strlen(message), inbound);
    }
    else {
        delivered = log_mail_transport(settings.hostname, from, to, message, error,
        sizeof(error));
    }
    free(message);
    lock();
    bool indexed = !delivered || move_message(id, "sent");
    unlock();
    log_json json = {
        reply_buffer, 0, sizeof(reply_buffer), false
    };
    log_json_text(&json, delivered ? "{\"accepted\":true,\"sent_indexed\":" : "{\"accepted\":false,\"sent_indexed\":");
    log_json_text(&json, delivered && indexed ? "true" : "false");
    log_json_text(&json, ",\"id\":");
    log_json_string(&json, id);
    log_json_text(&json, ",\"message\":");
    log_json_string(&json, delivered ? (indexed ? "Accepted by destination; stored in Sent." : "Accepted, but Sent index failed. Do not resend.") : error);
    log_json_text(&json, "}");
    response(out, delivered ? 200 : 502, reply_buffer);
    return true;
}
