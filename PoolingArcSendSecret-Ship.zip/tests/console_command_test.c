#include "console_commands.h"

#include <assert.h>
#include <string.h>

int main(void) {
    assert(log_command_parse("  STATUS\r\n") == LOG_COMMAND_STATUS);
    assert(log_command_parse("shutdown") == LOG_COMMAND_STOP);
    assert(log_command_parse("reload") == LOG_COMMAND_RESTART);
    assert(log_command_parse("logs off") == LOG_COMMAND_LOGS_OFF);
    assert(log_command_parse("ports open") == LOG_COMMAND_PORTS_OPEN);
    assert(log_command_parse("ports close") == LOG_COMMAND_PORTS_CLOSE);
    assert(log_command_parse("ports status") == LOG_COMMAND_PORTS_STATUS);
    assert(log_command_parse("/wipe") == LOG_COMMAND_WIPE);
    assert(log_command_parse("exit") == LOG_COMMAND_EXIT);
    assert(log_command_parse(" \t\r\n") == LOG_COMMAND_EMPTY);
    assert(log_command_parse("restart now") == LOG_COMMAND_UNKNOWN);
    assert(log_command_parse(NULL) == LOG_COMMAND_UNKNOWN);

    char oversized[512];
    memset(oversized, 'a', sizeof(oversized) - 1);
    oversized[sizeof(oversized) - 1] = '\0';
    assert(log_command_parse(oversized) == LOG_COMMAND_UNKNOWN);
    return 0;
}
