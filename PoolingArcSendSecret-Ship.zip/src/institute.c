#include "institute.h"
#include "form.h"
#include "cog.h"
#include "store.h"
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdatomic.h>
#ifdef _WIN32
#include <direct.h>
#define MKDIR(path) _mkdir(path)
#else
#include <sys/stat.h>
#define MKDIR(path) mkdir(path,0700)
#endif
#define USER_LIMIT 256
#define SESSION_LIMIT 128
#define ITERATIONS 600000
typedef struct {
    char name[33];
    unsigned char salt[16];
    unsigned char hash[32];
    int role;
    int iterations;
}
account;
typedef struct {
    unsigned char digest[32];
    char csrf[65];
    unsigned user;
    time_t expires;
}
session;
static account users[USER_LIMIT];
static unsigned user_count;
static session sessions[SESSION_LIMIT];
static char reply[512];
static bool initialized;
static atomic_bool admin_ready;
static atomic_bool https_ready;
void log_institute_set_https_ready(bool ready) {
    atomic_store(&https_ready,ready);
}
bool log_institute_https_ready(void) {
    return atomic_load(&https_ready);
}
bool log_institute_admin_exists(void){
    return atomic_load(&admin_ready);
}
static struct {
    char peer[64];
    time_t start;
    unsigned count;
}
limits[64];
static time_t global_start;
static unsigned global_count;
static void hex_encode(const unsigned char *data, size_t size, char *output) {
    const char *digits = "0123456789abcdef";
    for (size_t i = 0; i < size; ++i) {
        output[2*i] = digits[data[i] >> 4];
        output[2*i+1] = digits[data[i] & 15];
    }
    output[size*2] = 0;
}
static int unhex(const char *text, unsigned char *out, size_t size) {
    if (strlen(text) != size*2) return -1;
    for (size_t i = 0; i < size; ++i) {
        unsigned x;
        if (sscanf(text+2*i,"%2x",&x) != 1) return -1;
        out[i] = (unsigned char)x;
    }
    return 0;
}
static bool token(char output[65]) {
    unsigned char random[32];
    if (RAND_bytes(random,sizeof(random)) != 1) return false;
    hex_encode(random,sizeof(random),output);
    return true;
}
static void respond(log_response *r, int status, const char *message) {
    r->status = status;
    r->content_type = "application/json; charset=utf-8";
    r->body = message;
    r->body_length = strlen(message);
}
static bool save_user(unsigned index) {
    char salt[33],hash[65],record[128];
    hex_encode(users[index].salt,16,salt);
    hex_encode(users[index].hash,32,hash);
    snprintf(record,sizeof(record),"MEMBER1 %d %d %s %s",users[index].role, users[index].iterations,
    salt,hash);
    return log_cog_put("private/institute/members.cog","members", users[index].name,
    record,false)==0;
}
static bool username(char *text) {
    size_t n = strlen(text);
    if (n < 3 || n > 32) return false;
    for (size_t i=0;i<n;++i) {
        unsigned char c=(unsigned char)text[i];
        if (!(c>='a'&&c<='z') && !(c>='A'&&c<='Z') && !(c>='0'&&c<='9') && c!='_' && c!='-') return false;
        text[i]=(char)tolower(c);
    }
    return true;
}
static int load_member(const char *name,const char *value,void *unused) {
    (void)unused;
    char checked[33],salt[33],hash[65];
    int role,iterations;
    if(strlen(name)>32||user_count==USER_LIMIT)return -1;
    strcpy(checked,name);
    if(!username(checked)||strcmp(checked,name)|| sscanf(value,"MEMBER1 %d %d %32s %64s",
    &role,&iterations,salt,hash)!=4|| role<1||role>3||iterations<600000||iterations>4000000)return -1;
    account *u=&users[user_count];
    strcpy(u->name,name);
    u->role=role;
    u->iterations=iterations;
    if(unhex(salt,u->salt,16)||unhex(hash,u->hash,32))return -1;
    ++user_count;
    return 0;
}
bool log_institute_init(void) {
    if(initialized)return true;
    OPENSSL_init_crypto(OPENSSL_INIT_NO_LOAD_CONFIG,NULL);
    if(!log_store_prepare())return false;
    user_count=0;
    if(log_cog_scan("private/institute/members.cog","members",load_member,NULL))return false;
    FILE *f=NULL;
    bool admin=false;
    for(unsigned i=0;i<user_count;++i) admin |= users[i].role==3;
    if(!admin) {
        f=fopen("private/institute/setup.token","rb");
        if(f) fclose(f);
        else {
            char setup[65];
            if(!token(setup))return false;
            f=fopen("private/institute/setup.token","wb");
            if(!f)return false;
            bool ok=fwrite(setup,1,64,f)==64;
            if(fclose(f)||!ok)return false;
        }
    }
    atomic_store(&admin_ready,admin);
    initialized=true;
    return true;
}
static bool origin_ok(const log_request *r) {
    char expected[320];
    snprintf(expected,sizeof(expected),"https://%s",r->host);
    return r->host[0] && !strcmp(expected,r->origin);
}
static session *get_session(const log_request *r) {
    if(!r->secure)return NULL;
    const char *cursor=r->cookie;
    char value[65];
    while(*cursor) {
        while(*cursor==' '||*cursor==';')++cursor;
        const char *end=strchr(cursor,';');
        if(!end)end=cursor+strlen(cursor);
        if(end-cursor==76 && !memcmp(cursor,"__Host-pass=",12)) {
            memcpy(value,cursor+12,64);
            value[64]=0;
            unsigned char digest[32];
            if(EVP_Digest(value,64,digest,NULL,EVP_sha256(),NULL)!=1)return NULL;
            for(unsigned i=0;i<SESSION_LIMIT;++i) {
                if(sessions[i].expires>time(NULL) && !CRYPTO_memcmp(digest,sessions[i].digest,
                32))return &sessions[i];
            }
        }
        cursor=end;
    }
    return NULL;
}
int log_institute_role(const log_request *r,bool mutation) {
    session *s=get_session(r);
    if(!s)return 0;
    if(mutation && (!origin_ok(r)||strlen(r->csrf)!=64|| CRYPTO_memcmp(s->csrf,
    r->csrf,64)))return 0;
    return users[s->user].role;
}
static bool rate_ok(const char *peer) {
    time_t now=time(NULL);
    if(now-global_start>=60){
        global_start=now;
        global_count=0;
    }
    if(++global_count>60)return false;
    unsigned slot=0;
    for(unsigned i=0;i<64;++i) {
        if(!strcmp(limits[i].peer,peer)){
            slot=i;
            break;
        }
        if(limits[i].start<limits[slot].start)slot=i;
    }
    if(strcmp(limits[slot].peer,peer)||now-limits[slot].start>=60) {
        snprintf(limits[slot].peer,64,"%s",peer);
        limits[slot].start=now;
        limits[slot].count=0;
    }
    return ++limits[slot].count<=10;
}
static bool issue_session(unsigned index,log_response *out,int status) {
    unsigned slot=0;
    for(unsigned i=1;i<SESSION_LIMIT;++i)if(sessions[i].expires<sessions[slot].expires)slot=i;
    char cookie[65];
    if(!token(cookie)||!token(sessions[slot].csrf)) {
        respond(out,500,"{\"error\":\"Crypto failure\"}");
        return true;
    }
    if(EVP_Digest(cookie,64,sessions[slot].digest,NULL,EVP_sha256(),NULL)!=1) {
        respond(out,500,"{\"error\":\"Session digest failure\"}");
        return true;
    }
    sessions[slot].user=index;
    sessions[slot].expires=time(NULL)+3600;
    snprintf(out->cookie_header,sizeof(out->cookie_header), "Set-Cookie: __Host-pass=%s; Max-Age=3600; Path=/; Secure; HttpOnly; SameSite=Strict\r\n",
    cookie);
    respond(out,status,"{\"ok\":true,\"authenticated\":true}");
    return true;
}
bool log_institute_handle(const log_request *r,log_response *out) {
    if(strncmp(r->path,"/api/institute/",15))return false;
    respond(out,404,"{\"error\":\"Unknown Institute endpoint\"}");
    if(!initialized){
        respond(out,503,"{\"error\":\"Institute unavailable\"}");
        return true;
    }
    if(!strcmp(r->path,"/api/institute/status")&&!strcmp(r->method,"GET")) {
        snprintf(reply,sizeof(reply),"{\"live\":%s,\"https\":%s}",
            log_institute_admin_exists()?"true":"false",
            log_institute_https_ready()?"true":"false");
        respond(out,200,reply);
        return true;
    }
    if(!r->secure){
        respond(out,426,"{\"error\":\"HTTPS required\"}");
        return true;
    }
    session *s=get_session(r);
    if(!strcmp(r->path,"/api/institute/session")&&!strcmp(r->method,"GET")) {
        if(!s){
            respond(out,401,"{\"authenticated\":false}");
            return true;
        }
        snprintf(reply,sizeof(reply), "{\"authenticated\":true,\"username\":\"%s\",\"role\":%d,\"csrf\":\"%s\"}",
        !strcmp(users[s->user].name,"sshhm")?"Sshhm":users[s->user].name, users[s->user].role,
        s->csrf);
        respond(out,200,reply);
        return true;
    }
    if(!strcmp(r->path,"/api/institute/members")&&!strcmp(r->method,"GET")) {
        if(log_institute_role(r,false)!=3){
            respond(out,403,"{\"error\":\"Administrator required\"}");
            return true;
        }
        static char members[32768];
        size_t used=0;
        members[used++]='[';
        for(unsigned i=0;i<user_count;++i) {
            int n=snprintf(members+used,sizeof(members)-used, "%s{\"username\":\"%s\",\"role\":%d}",
            i?",":"", users[i].name,users[i].role);
            if(n<0||(size_t)n>=sizeof(members)-used){
                respond(out,500,"{}");
                return true;
            }
            used+=(size_t)n;
        }
        members[used++]=']';
        members[used]=0;
        respond(out,200,members);
        return true;
    }
    if(strcmp(r->method,"POST"))return true;
    if(!origin_ok(r)){
        respond(out,403,"{\"error\":\"Origin rejected\"}");
        return true;
    }
    if(!strcmp(r->path,"/api/institute/members")) {
        if(log_institute_role(r,true)!=3){
            respond(out,403,"{\"error\":\"Administrator/CSRF required\"}");
            return true;
        }
        char name[33],action[16];
        if(log_form_get(r->body,r->body_length,"username",name,sizeof(name))|| log_form_get(r->body,
        r->body_length,"action",action,sizeof(action))|| !username(name)){
            respond(out,400,"{\"error\":\"Invalid member action\"}");
            return true;
        }
        unsigned index=user_count;
        for(unsigned i=0;i<user_count;++i)if(!strcmp(name,users[i].name))index=i;
        if(index==user_count||users[index].role==3){
            respond(out,403,"{\"error\":\"Primary administrator is protected or member missing\"}");
            return true;
        }
        if(!strcmp(action,"delete")) {
            if(log_cog_remove("private/institute/members.cog","members",name)) {
                respond(out,500,"{\"error\":\"Storage failed\"}");
                return true;
            }
            memmove(users+index,users+index+1,(user_count-index-1)*sizeof(account));
            --user_count;
        }
        else if(!strcmp(action,"role")) {
            char role[2];
            if(log_form_get(r->body,r->body_length,"role",role,sizeof(role))|| (strcmp(role,
            "1")&&strcmp(role,"2"))){
                respond(out,400,"{\"error\":\"Use member or moderator role\"}");
                return true;
            }
            int before=users[index].role;
            users[index].role=role[0]-'0';
            if(!save_user(index)){
                users[index].role=before;
                respond(out,500,"{\"error\":\"Storage failed\"}");
                return true;
            }
        }
        else {
            respond(out,400,"{\"error\":\"Unknown action\"}");
            return true;
        }
        memset(sessions,0,sizeof(sessions));
        respond(out,200,"{\"ok\":true,\"message\":\"Updated. Sign in again.\"}");
        return true;
    }
    if(!strcmp(r->path,"/api/institute/password")) {
        if(!s||!log_institute_role(r,true)){
            respond(out,403,"{\"error\":\"Session/CSRF rejected\"}");
            return true;
        }
        if(!rate_ok(r->peer)){
            respond(out,429,"{\"error\":\"Try later\"}");
            return true;
        }
        char current[129],password[129],confirm[129];
        unsigned char digest[32];
        if(log_form_get(r->body,r->body_length,"current",current,sizeof(current))|| log_form_get(r->body,
        r->body_length,"password",password,sizeof(password))|| log_form_get(r->body,
        r->body_length,"confirm",confirm,sizeof(confirm))|| strlen(password)<15||strcmp(password,
        confirm)) {
            respond(out,400,"{\"error\":\"Invalid password fields\"}");
            return true;
        }
        account *u=&users[s->user];
        int ok=PKCS5_PBKDF2_HMAC(current,(int)strlen(current),u->salt,16, u->iterations,
        EVP_sha256(),32,digest);
        OPENSSL_cleanse(current,sizeof(current));
        if(ok!=1||CRYPTO_memcmp(digest,u->hash,32)){
            respond(out,401,"{\"error\":\"Current password incorrect\"}");
            return true;
        }
        account before=*u;
        u->iterations=ITERATIONS;
        if(RAND_bytes(u->salt,16)!=1||PKCS5_PBKDF2_HMAC(password, (int)strlen(password),
        u->salt,16,ITERATIONS,EVP_sha256(),32,u->hash)!=1|| !save_user(s->user)) {
            *u=before;
            respond(out,500,"{\"error\":\"Password update failed\"}");
            return true;
        }
        OPENSSL_cleanse(password,sizeof(password));
        memset(sessions,0,sizeof(sessions));
        respond(out,200,"{\"ok\":true}");
        return true;
    }
    if(!strcmp(r->path,"/api/institute/logout")) {
        if(!log_institute_role(r,true)){
            respond(out,403,"{\"error\":\"CSRF/session rejected\"}");
            return true;
        }
        s->expires=0;
        strcpy(out->cookie_header,"Set-Cookie: __Host-pass=; Max-Age=0; Path=/; Secure; HttpOnly; SameSite=Strict\r\n");
        respond(out,200,"{\"ok\":true}");
        return true;
    }
    bool setup_request=!strcmp(r->path,"/api/institute/setup");
    if(strcmp(r->path,"/api/institute/register") && strcmp(r->path,"/api/institute/login") && !setup_request)return true;
    if((setup_request&&log_institute_admin_exists())|| (!setup_request&&!log_institute_admin_exists())) {
        respond(out,409,"{\"error\":\"Owner setup is required or already completed\"}");
        return true;
    }
    if(!rate_ok(r->peer)){
        respond(out,429,"{\"error\":\"Try again in a minute\"}");
        return true;
    }
    char name[33],password[129];
    if(log_form_get(r->body,r->body_length,"username",name,sizeof(name))|| log_form_get(r->body,
    r->body_length,"password",password,sizeof(password))|| !username(name)||strlen(password)<15) {
        respond(out,400,"{\"error\":\"Use a 3-32 character username and 15-128 byte password\"}");
        return true;
    }
    unsigned index=user_count;
    for(unsigned i=0;i<user_count;++i)if(!strcmp(users[i].name,name))index=i;
    if(setup_request||!strcmp(r->path,"/api/institute/register")) {
        char confirm[129],honeypot[128];
        if(log_form_get(r->body,r->body_length,"confirm",confirm,sizeof(confirm))|| strcmp(confirm,
        password)) {
            respond(out,400,"{\"error\":\"Passwords do not match\"}");
            return true;
        }
        if(!log_form_get(r->body,r->body_length,"website",honeypot,sizeof(honeypot))&&*honeypot) {
            respond(out,400,"{\"error\":\"Registration rejected\"}");
            return true;
        }
        if(index!=user_count){
            respond(out,409,"{\"error\":\"Username unavailable\"}");
            return true;
        }
        if(user_count==USER_LIMIT){
            respond(out,503,"{\"error\":\"Account capacity reached\"}");
            return true;
        }
        account next={
            0
        };
        strcpy(next.name,name);
        next.role=1;
        next.iterations=ITERATIONS;
        char setup[65], expected[65]={
            0
        };
        bool promote=false;
        if(setup_request && !log_form_get(r->body,r->body_length,"setup",setup,
        sizeof(setup))&&*setup) {
            FILE *f=fopen("private/institute/setup.token","rb");
            size_t n=f?fread(expected,1,64,f):0;
            if(f)fclose(f);
            promote=n==64&&strlen(setup)==64&&!CRYPTO_memcmp(setup,expected,64);
            if(!promote){
                respond(out,403,"{\"error\":\"Invalid setup token\"}");
                return true;
            }
        }
        bool already_admin=false;
        for(unsigned i=0;i<user_count;++i)already_admin|=users[i].role==3;
        if((setup_request&&!promote)||(!strcmp(name,"sshhm")&&!promote)|| (promote&&(already_admin||strcmp(name,
        "sshhm")))) {
            respond(out,403,"{\"error\":\"Sshhm is reserved; first administrator needs its setup token\"}");
            return true;
        }
        if(promote)next.role=3;
        bool ok=RAND_bytes(next.salt,16)==1&&PKCS5_PBKDF2_HMAC(password, (int)strlen(password),
        next.salt,16,ITERATIONS,EVP_sha256(),32,next.hash)==1;
        OPENSSL_cleanse(password,sizeof(password));
        if(!ok){
            respond(out,500,"{\"error\":\"Crypto failure\"}");
            return true;
        }
        users[user_count++]=next;
        if(!save_user(user_count-1)){
            --user_count;
            respond(out,500,"{\"error\":\"Could not save account\"}");
            return true;
        }
        if(promote){
            remove("private/institute/setup.token");
            atomic_store(&admin_ready,true);
        }
        return issue_session(user_count-1,out,201);
    }
    unsigned char computed[32],dummy[16]={
        0
    };
    bool ok=PKCS5_PBKDF2_HMAC(password,(int)strlen(password), index<user_count?users[index].salt:dummy,
    16, index<user_count?users[index].iterations:ITERATIONS, EVP_sha256(),32,
    computed)==1;
    OPENSSL_cleanse(password,sizeof(password));
    if(!ok||index==user_count||CRYPTO_memcmp(computed,users[index].hash,32)) {
        respond(out,401,"{\"error\":\"Invalid credentials\"}");
        return true;
    }
    return issue_session(index,out,200);
}
