#include "tls.h"
#include <windows.h>
#include <ws2tcpip.h>
#include <direct.h>
#include "smtp.h"
#include "mail.h"
#include "smtp_policy.h"
#include "institute.h"
#include "logging.h"
#include "cog.h"
#include "store.h"
#include <openssl/rand.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static HANDLE worker;
static SOCKET listener=INVALID_SOCKET;
static SSL_CTX *context;
static volatile LONG stopping;
static log_pool_config settings;
static unsigned long long spool_bytes;
typedef struct {
    SOCKET socket_handle;
    SSL *tls;
    char buffer[4096];
    int used,position;
    ULONGLONG deadline;
}
smtp_io;
static bool send_text(smtp_io *io,const char *text){
    size_t size=strlen(text);
    while(size){
        int n=log_stream_send(io->socket_handle,io->tls,text,(int)size);
        if(n<=0)return false;
        text+=n;
        size-=(size_t)n;
    }
    return true;
}
static int read_line(smtp_io *io,char *line,size_t capacity){
    size_t count=0;
    while(count+1<capacity){
        if(InterlockedCompareExchange(&stopping,0,0)|| GetTickCount64()>io->deadline)return -1;
        if(io->position==io->used){
            io->used=log_stream_receive(io->socket_handle,io->tls, io->buffer,
            sizeof(io->buffer));
            io->position=0;
            if(io->used<=0)return -1;
        }
        char c=io->buffer[io->position++];
        if(!c)return -1;
        line[count++]=c;
        if(c=='\n'){
            if(count<2||line[count-2]!='\r')return -1;
            line[count-2]=0;
            return (int)(count-2);
        }
    }
    return -1;
}
static bool receive_message(smtp_io *io,const char *from,const char *to){
    if(spool_bytes>=268435456ULL){
        send_text(io,"452 Spool capacity reached\r\n");
        return false;
    }
    unsigned char random[16];
    if(RAND_bytes(random,16)!=1)return false;
    char id[33],path[128],temporary[132];
    const char *digits="0123456789abcdef";
    for(unsigned i=0;i<16;++i){
        id[2*i]=digits[random[i]>>4];
        id[2*i+1]=digits[random[i]&15];
    }
    id[32]=0;
    snprintf(path,sizeof(path),"Mail/Sshhm/inbox/%s.eml",id);
    snprintf(temporary,sizeof(temporary),"%s.tmp",path);
    FILE *file=fopen(temporary,"wb");
    if(!file)return false;
    bool ok=fprintf(file,"X-Pool-Envelope-From: <%s>\r\nX-Pool-Envelope-To: <%s>\r\n",
    from,to)>0;
    if(!send_text(io,"354 End with <CRLF>.<CRLF>\r\n")){
        fclose(file);
        remove(temporary);
        return false;
    }
    char line[1001];
    size_t size=0;
    bool complete=false;
    while(ok){
        int n=read_line(io,line,sizeof(line));
        if(n<0)break;
        if(!strcmp(line,".")){
            complete=true;
            break;
        }
        const char *data=line;
        if(line[0]=='.')++data;
        size_t length=strlen(data);
        if(size+length+2>settings.smtp_max_size|| spool_bytes+size+length+2>268435456ULL){
            ok=false;
            break;
        }
        ok=fwrite(data,1,length,file)==length&&fwrite("\r\n",1,2,file)==2;
        size+=length+2;
    }
    if(fclose(file))ok=false;
    if(!ok||!complete||log_store_replace(temporary,path)){
        remove(temporary);
        send_text(io,"552 Message rejected or storage failed\r\n");
        return false;
    }
    if(!log_mail_commit(id,size,from,to,path)) {
        remove(path);
        send_text(io,"452 Could not commit message index\r\n");
        return false;
    }
    spool_bytes+=size;
    log_write("SMTP","Accepted mail for %s (%zu bytes)",to,size);
    return send_text(io,"250 Message stored for local mailbox\r\n");
}
static void session(SOCKET client,const char *peer){
    smtp_io io={
        0
    };
    io.socket_handle=client;
    io.deadline=GetTickCount64()+120000;
    char line[1001],from[256]={
        0
    },to[256]={
        0
    };
    bool greeted=false,mail=false;
    char greeting[400];
    snprintf(greeting,sizeof(greeting),"220 %s ESMTP PoolingArcSendSecret\r\n",
    settings.hostname);
    send_text(&io,greeting);
    for(unsigned commands=0;commands<100;++commands){
        if(read_line(&io,line,sizeof(line))<0)break;
        if(!_strnicmp(line,"EHLO ",5)||!_strnicmp(line,"HELO ",5)){
            greeted=true;
            mail=false;
            to[0]=0;
            send_text(&io,io.tls||!context?"250 Hello\r\n":"250-Hello\r\n250 STARTTLS\r\n");
        }
        else if(!_stricmp(line,"QUIT")){
            send_text(&io,"221 Bye\r\n");
            break;
        }
        else if(!_stricmp(line,"NOOP")){
            send_text(&io,"250 OK\r\n");
        }
        else if(!_stricmp(line,"RSET")){
            mail=false;
            to[0]=0;
            send_text(&io,"250 Reset\r\n");
        }
        else if(!_stricmp(line,"STARTTLS")&&context&&!io.tls&&greeted){
            if(io.position!=io.used){
                send_text(&io,"554 No STARTTLS pipelining\r\n");
                break;
            }
            if(!send_text(&io,"220 Start TLS\r\n"))break;
            io.tls=SSL_new(context);
            if(!io.tls||SSL_set_fd(io.tls,(int)client)!=1||!log_tls_accept(io.tls,
            peer))break;
            greeted=false;
            mail=false;
            to[0]=0;
        }
        else if(!_strnicmp(line,"MAIL FROM:",10)&&greeted){
            mail=log_smtp_address(line+10,from,sizeof(from));
            to[0]=0;
            send_text(&io,mail?"250 Sender accepted\r\n":"501 Invalid sender syntax\r\n");
        }
        else if(!_strnicmp(line,"RCPT TO:",8)&&mail){
            if(!log_institute_admin_exists()){
                send_text(&io,"450 Administrator mailbox not configured\r\n");
                continue;
            }
            if(to[0]){
                send_text(&io,"452 One recipient per transaction\r\n");
                continue;
            }
            char proposed[256];
            if(log_smtp_address(line+8,proposed,sizeof(proposed))&& log_smtp_recipient(&settings,
            proposed)){
                strcpy(to,proposed);
                send_text(&io,"250 Local recipient accepted\r\n");
            }
            else send_text(&io,"550 Relay denied or unknown local recipient\r\n");
        }
        else if(!_stricmp(line,"DATA")&&mail&&to[0]){
            if(!receive_message(&io,from,to))break;
            mail=false;
            to[0]=0;
        }
        else send_text(&io,"503 Unsupported command or bad sequence\r\n");
    }
    if(io.tls)(void)SSL_shutdown(io.tls);
    SSL_free(io.tls);
}
static DWORD WINAPI run(void *unused){
    (void)unused;
    while(!InterlockedCompareExchange(&stopping,0,0)){
        fd_set ready;
        FD_ZERO(&ready);
        FD_SET(listener,&ready);
        struct timeval timeout={
            0,200000
        };
        if(select(0,&ready,NULL,NULL,&timeout)<=0)continue;
        struct sockaddr_in peer;
        int length=sizeof(peer);
        SOCKET client=accept(listener,(struct sockaddr *)&peer,&length);
        if(client==INVALID_SOCKET)continue;
        DWORD ms=5000;
        setsockopt(client,SOL_SOCKET,SO_RCVTIMEO,(char *)&ms,sizeof(ms));
        setsockopt(client,SOL_SOCKET,SO_SNDTIMEO,(char *)&ms,sizeof(ms));
        char ip[INET_ADDRSTRLEN]="unknown";
        InetNtopA(AF_INET,&peer.sin_addr,ip,sizeof(ip));
        log_write("SMTP","%s connected",ip);
        session(client,ip);
        closesocket(client);
        log_write("SMTP","%s disconnected",ip);
    }
    return 0;
}
static int count_spool(const char *key,const char *value,void *unused){
    (void)key;
    (void)unused;
    char *end;
    unsigned long long bytes=strtoull(value,&end,10);
    if(*end!='\t'||bytes>268435456ULL||spool_bytes+bytes>268435456ULL)return -1;
    spool_bytes+=bytes;
    return 0;
}
bool log_smtp_start(const log_pool_config *config){
    if(!config->smtp_enabled)return true;
    if(worker)return true;
    settings=*config;
    spool_bytes=0;
    if(log_cog_scan(LOG_MAIL_INDEX,"messages",count_spool,NULL))return false;
    WSADATA data;
    if(WSAStartup(MAKEWORD(2,2),&data))return false;
    context=log_tls_context(config->https_certificate,config->https_private_key);
    if(!context){
        WSACleanup();
        return false;
    }
    listener=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    struct sockaddr_in address={
        0
    };
    address.sin_family=AF_INET;
    address.sin_port=htons(config->smtp_port);
    if(listener==INVALID_SOCKET||InetPtonA(AF_INET,config->smtp_bind,&address.sin_addr)!=1|| bind(listener,
    (struct sockaddr *)&address,sizeof(address))==SOCKET_ERROR|| listen(listener,
    16)==SOCKET_ERROR){
        log_write("SMTP","Bind failed on TCP %u (Winsock %d)", (unsigned)config->smtp_port,
        WSAGetLastError());
        if(listener!=INVALID_SOCKET)closesocket(listener);
        SSL_CTX_free(context);
        context=NULL;
        WSACleanup();
        return false;
    }
    InterlockedExchange(&stopping,0);
    worker=CreateThread(NULL,0,run,NULL,0,NULL);
    if(!worker){
        closesocket(listener);
        SSL_CTX_free(context);
        context=NULL;
        WSACleanup();
        return false;
    }
    log_write("SMTP","Inbound TCP %u, STARTTLS, local Sshhm mailbox only", (unsigned)config->smtp_port);
    return true;
}
bool log_smtp_running(void){
    return worker!=NULL;
}
void log_smtp_stop(void){
    if(!worker)return;
    InterlockedExchange(&stopping,1);
    WaitForSingleObject(worker,INFINITE);
    CloseHandle(worker);
    worker=NULL;
    closesocket(listener);
    listener=INVALID_SOCKET;
    SSL_CTX_free(context);
    context=NULL;
    WSACleanup();
}
