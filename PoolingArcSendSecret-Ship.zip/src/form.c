#include "form.h"
#include <string.h>
static int hex(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
int log_form_get(const char *body, size_t length, const char *name, char *output,
size_t capacity) {
    if (!body || !output || !capacity) return -1;
    output[0] = 0;
    int found = 0;
    for (size_t pos = 0; pos < length;) {
        size_t end = pos;
        while (end < length && body[end] != '&') ++end;
        size_t equal = pos;
        while (equal < end && body[equal] != '=') ++equal;
        if (equal - pos == strlen(name) && !memcmp(body + pos, name, equal-pos)) {
            if (found++ || equal == end) return -1;
            size_t used = 0;
            for (size_t i = equal + 1; i < end; ++i) {
                unsigned char c = (unsigned char)body[i];
                if (c == '+') c = ' ';
                else if (c == '%') {
                    if (i + 2 >= end || hex(body[i+1]) < 0 || hex(body[i+2]) < 0) {
                        return -1;
                    }
                    c = (unsigned char)(hex(body[i+1])*16 + hex(body[i+2]));
                    i += 2;
                }
                if (!c || used + 1 >= capacity) return -1;
                output[used++] = (char)c;
            }
            output[used] = 0;
        }
        pos = end + 1;
    }
    return found ? 0 : -1;
}
