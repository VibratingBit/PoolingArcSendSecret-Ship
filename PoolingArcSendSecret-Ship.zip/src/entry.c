#include "entry.h"
#include "http.h"
#include "logging.h"
#include "tls.h"
#include "institute.h"
#include "cms.h"
#include "assets.h"
#include "media.h"
#include "mail.h"

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define LOG_ROUTES 64
#define LOG_STOP_EVENT "Local\\ProofOrderObligedLog_Stop_v1"

/* This is a single-instance local developer server, not a service manager. */
typedef struct {
    char method[12];
    char path[1024];
    log_handler handler;
} log_route;

struct log_server {
    log_route routes[LOG_ROUTES];
    size_t route_count;
    volatile LONG running;
    volatile LONG tls_running;
    volatile LONG stop_requested;
    SOCKET listener;
    HANDLE stop_event;
    volatile LONG64 requests;
    volatile LONG64 errors;
    volatile LONG64 bytes_sent;
    time_t started;
    char tls_bind[46];
    uint16_t tls_port;
    char certificate[512];
    char private_key[512];
};

int log_control(const char *action) {
    HANDLE event = OpenEventA(
        EVENT_MODIFY_STATE | SYNCHRONIZE,
        FALSE,
        LOG_STOP_EVENT
    );

    if (event == NULL) {
        fprintf(stderr, "LOG server is offline.\n");
        return 1;
    }

    if (strcmp(action, "--shutdown") == 0) {
        BOOL result = SetEvent(event);
        CloseHandle(event);
        return result ? 0 : 1;
    }

    CloseHandle(event);
    return 0;
}

log_server *log_server_create(void) {
    log_server *server = calloc(1, sizeof(log_server));
    if (server != NULL) {
        server->listener = INVALID_SOCKET;
    }
    return server;
}

bool log_server_route(
    log_server *server,
    const char *method,
    const char *path,
    log_handler handler
) {
    if (server == NULL || method == NULL || path == NULL ||
        handler == NULL || server->route_count == LOG_ROUTES ||
        strlen(method) >= sizeof(server->routes[0].method) ||
        strlen(path) >= sizeof(server->routes[0].path) ||
        path[0] != '/') {
        return false;
    }

    for (size_t index = 0; index < server->route_count; ++index) {
        log_route *existing = &server->routes[index];
        if (strcmp(existing->method, method) == 0 &&
            strcmp(existing->path, path) == 0) {
            return false;
        }
    }

    log_route *route = &server->routes[server->route_count++];
    strcpy(route->method, method);
    strcpy(route->path, path);
    route->handler = handler;
    return true;
}

static bool send_all(
    SOCKET socket_handle,
    SSL *tls,
    const char *data,
    size_t size
) {
    while (size > 0) {
        int chunk = (int)(size > 16384 ? 16384 : size);
        int sent = log_stream_send(socket_handle, tls, data, chunk);

        if (sent <= 0) {
            return false;
        }

        data += sent;
        size -= (size_t)sent;
    }

    return true;
}

static char *find_header_end(char *buffer, size_t size) {
    if (size < 4) {
        return NULL;
    }

    for (size_t index = 0; index <= size - 4; ++index) {
        if (memcmp(buffer + index, "\r\n\r\n", 4) == 0) {
            return buffer + index;
        }
    }

    return NULL;
}

/* Determine request length without inspecting unreceived bytes. */
static int expected_length(
    char *buffer,
    size_t used,
    size_t *expected
) {
    char *headers_end = find_header_end(buffer, used);
    if (headers_end == NULL) {
        return used > LOG_MAX_REQUEST ? 431 : -1;
    }

    size_t header_size = (size_t)(headers_end + 4 - buffer);
    if (header_size > LOG_MAX_REQUEST) {
        return 431;
    }

    size_t body_length = 0;
    char *cursor = buffer;

    while (cursor < headers_end) {
        char *end = NULL;
        for (char *it = cursor; it + 1 < headers_end + 2; ++it) {
            if (it[0] == '\r' && it[1] == '\n') {
                end = it;
                break;
            }
        }

        if (end == NULL) {
            return 400;
        }

        if (end - cursor >= 15 &&
            _strnicmp(cursor, "Content-Length:", 15) == 0) {
            char *value = cursor + 15;
            while (value < end && (*value == ' ' || *value == '\t')) {
                ++value;
            }

            if (value == end) {
                return 400;
            }

            for (; value < end; ++value) {
                if (*value < '0' || *value > '9') {
                    return 400;
                }

                unsigned digit = (unsigned)(*value - '0');
                if (body_length > (LOG_MAX_BODY - digit) / 10) {
                    return 413;
                }
                body_length = body_length * 10 + digit;
            }
        }

        cursor = end + 2;
    }

    *expected = header_size + body_length;
    return used >= *expected ? 0 : -1;
}

static void set_text_response(
    log_response *response,
    int status,
    const char *message
) {
    response->status = status;
    response->content_type = "text/plain; charset=utf-8";
    response->body = message;
    response->body_length = strlen(message);
}

static void serve_admin(
    log_server *server,
    const log_request *request,
    log_response *response,
    bool local_client
) {
    if (strcmp(request->method, "GET") != 0) {
        set_text_response(response, 405, "Method Not Allowed");
        return;
    }

    if (!local_client && log_institute_role(request, false) < 2) {
        set_text_response(response, 403, "Forbidden");
        return;
    }

    if (strcmp(request->path, "/api/metrics") == 0) {
        static char metrics[384];
        log_server_stats stats;
        log_server_snapshot(server, &stats);
        snprintf(
            metrics,
            sizeof(metrics),
            "{\"requests\":%llu,\"errors\":%llu,"
            "\"bytes_sent\":%llu,\"uptime_seconds\":%llu}",
            (unsigned long long)stats.requests,
            (unsigned long long)stats.errors,
            (unsigned long long)stats.bytes_sent,
            (unsigned long long)stats.uptime_seconds
        );

        response->status = 200;
        response->content_type = "application/json; charset=utf-8";
        response->body = metrics;
        response->body_length = strlen(metrics);
        return;
    }


}

static void serve(
    log_server *server,
    SOCKET client,
    bool local_client,
    const char *peer_address,
    SSL *tls
) {
    const size_t capacity = LOG_MAX_REQUEST + LOG_MAX_BODY;
    char *buffer = malloc(capacity + 1);
    if (buffer == NULL) {
        return;
    }

    size_t used = 0;
    size_t expected = 0;
    int status = 400;

    /* One request per connection; bounded memory and socket timeouts. */
    while (used < capacity) {
        if (InterlockedCompareExchange(&server->stop_requested, 0, 0)) {
            OPENSSL_cleanse(buffer, used);
            free(buffer);
            return;
        }
        size_t available = capacity - used;
        int chunk = (int)(available > 8192 ? 8192 : available);
        int received = log_stream_receive(client, tls, buffer + used, chunk);

        if (received <= 0) {
            break;
        }

        used += (size_t)received;
        buffer[used] = '\0';
        status = expected_length(buffer, used, &expected);

        if (status != -1) {
            break;
        }
    }

    if (used == capacity && status == -1) {
        status = 413;
    }

    if (status < 0) {
        status = 400;
    }

    log_request request = {0};
    log_response response = {0};

    if (status == 0) {
        status = log_http_parse(buffer, used, &request);
    }

    char activity_path[1024] = "<invalid>";
    if (status == 0) {
        request.secure = tls != NULL;
        snprintf(request.peer, sizeof(request.peer), "%s", peer_address);
        strcpy(activity_path, request.path);
        char *query = strchr(request.path, '?');
        if (query) {
            snprintf(request.query,sizeof(request.query),"%s",query+1);
            *query = '\0';
        }
        InterlockedIncrement64(&server->requests);

        if (log_institute_handle(&request, &response)) {
            /* Institute endpoint handled. */
        } else if (log_media_handle(&request, &response)) {
        } else if (log_mail_handle(&request, &response)) {
        } else if (log_cms_handle(&request, &response)) {
            /* CMS endpoint handled. */
        } else if (strcmp(request.path, "/api/metrics") == 0) {
            serve_admin(server, &request, &response, local_client);
        } else {
            set_text_response(&response, 404, "Not Found");

            for (size_t index = 0; index < server->route_count; ++index) {
                const log_route *route = &server->routes[index];
                if (strcmp(route->method, request.method) == 0 &&
                    strcmp(route->path, request.path) == 0) {
                    route->handler(&request, &response);
                    break;
                }
            }
        }

        if (response.status == 404 && !strcmp(request.method, "GET")) {
            log_asset_response(&request, &response);
        }
        status = response.status;
    }

    if (status >= 400) {
        InterlockedIncrement64(&server->errors);
    }

    if (response.body == NULL) {
        set_text_response(&response, status, log_http_reason(status));
    }

    if (response.content_type == NULL) {
        response.content_type = "application/octet-stream";
    }

    char header[1536];
    int header_size = snprintf(
        header,
        sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "Cache-Control: no-store\r\n"
        "X-Content-Type-Options: nosniff\r\n"
        "Content-Security-Policy: default-src 'self'; script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; img-src 'self' https: http:; "
        "media-src 'self' https: http:; object-src 'none'; "
        "base-uri 'self'; frame-ancestors 'none'; form-action 'self'\r\n"
        "%s\r\n",
        status,
        log_http_reason(status),
        response.content_type,
        response.body_length,
        response.cookie_header
    );

    if (header_size > 0 && header_size < (int)sizeof(header)) {
        bool success = send_all(client, tls, header, (size_t)header_size);
        if (response.body_length > 0 && success) {
            success = send_all(client, tls, response.body, response.body_length);
        }

        if (success) {
            InterlockedExchangeAdd64(
                &server->bytes_sent,
                (LONG64)header_size + (LONG64)response.body_length
            );
        }
    }

    if (log_access_is_enabled()) {
        log_write(
            "HTTP",
            "%s | %s %s -> %d (%zu response bytes)",
            peer_address,
            request.method[0] ? request.method : "<invalid>",
            activity_path,
            status,
            response.body_length
        );
    }
    OPENSSL_cleanse(buffer, used);
    free(buffer);
}

bool log_server_enable_tls(
    log_server *server,
    const char *bind_address,
    uint16_t port,
    const char *certificate,
    const char *private_key
) {
    if (server == NULL || bind_address == NULL || certificate == NULL ||
        private_key == NULL || port == 0 ||
        strlen(bind_address) >= sizeof(server->tls_bind) ||
        strlen(certificate) >= sizeof(server->certificate) ||
        strlen(private_key) >= sizeof(server->private_key)) {
        return false;
    }
    strcpy(server->tls_bind, bind_address);
    strcpy(server->certificate, certificate);
    strcpy(server->private_key, private_key);
    server->tls_port = port;
    return true;
}

static SOCKET create_listener(const char *host, uint16_t port) {
    SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listener == INVALID_SOCKET) {
        return INVALID_SOCKET;
    }
    struct sockaddr_in address = {0};
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    if (InetPtonA(AF_INET, host, &address.sin_addr) != 1 ||
        bind(listener, (struct sockaddr *)&address, sizeof(address)) ==
            SOCKET_ERROR ||
        listen(listener, SOMAXCONN) == SOCKET_ERROR) {
        log_write("NETWORK", "Cannot bind %s:%u (Winsock %d)",
            host, (unsigned)port, WSAGetLastError());
        closesocket(listener);
        return INVALID_SOCKET;
    }
    return listener;
}

int log_server_run(log_server *server, const char *host, uint16_t port) {
    WSADATA wsa;
    SOCKET http = INVALID_SOCKET;
    SOCKET https = INVALID_SOCKET;
    SSL_CTX *context = NULL;
    int result = 1;

    if (server == NULL || host == NULL) {
        return 1;
    }
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        return 1;
    }
    http = create_listener(host, port);
    if (http == INVALID_SOCKET) {
        goto cleanup;
    }
    if (server->tls_port != 0) {
        context = log_tls_context(server->certificate, server->private_key);
        if (context != NULL) {
            https = create_listener(server->tls_bind,server->tls_port);
            if (https == INVALID_SOCKET) {
                SSL_CTX_free(context);
                context = NULL;
            }
        }
        if (https == INVALID_SOCKET) {
            log_write("TLS","HTTPS offline; HTTP port %u remains available.",(unsigned)port);
            log_write("TLS","Accounts and mail still require HTTPS. Fix the PEM paths, then restart.");
        }
    }
    server->stop_event = CreateEventA(NULL, TRUE, FALSE, LOG_STOP_EVENT);
    if (server->stop_event == NULL ||
        GetLastError() == ERROR_ALREADY_EXISTS) {
        log_write("ERROR", "Another server instance may already be running.");
        goto cleanup;
    }
    server->listener = http;
    server->started = time(NULL);
    InterlockedExchange(&server->tls_running,https != INVALID_SOCKET);
    log_institute_set_https_ready(https != INVALID_SOCKET);
    InterlockedExchange(&server->running, 1);
    log_write("SERVER", "HTTP listening on http://%s:%u", host, (unsigned)port);
    if (https != INVALID_SOCKET) {
        log_write("SERVER", "HTTPS listening on https://%s:%u",
            server->tls_bind, (unsigned)server->tls_port);
    }
    result = 0;
    while (!InterlockedCompareExchange(&server->stop_requested, 0, 0) &&
           WaitForSingleObject(server->stop_event, 0) != WAIT_OBJECT_0) {
        fd_set readable;
        struct timeval timeout = {0};
        timeout.tv_usec = 200000;
        FD_ZERO(&readable);
        FD_SET(http, &readable);
        if (https != INVALID_SOCKET) {
            FD_SET(https, &readable);
        }
        int ready = select(0, &readable, NULL, NULL, &timeout);
        if (ready == 0) {
            continue;
        }
        if (ready == SOCKET_ERROR) {
            result = 1;
            break;
        }
        bool secure = https != INVALID_SOCKET && FD_ISSET(https, &readable);
        SOCKET selected = secure ? https : http;
        struct sockaddr_in peer = {0};
        int peer_length = sizeof(peer);
        SOCKET client = accept(
            selected, (struct sockaddr *)&peer, &peer_length
        );
        if (client == INVALID_SOCKET) {
            result = 1;
            break;
        }
        DWORD milliseconds = 5000;
        setsockopt(client, SOL_SOCKET, SO_RCVTIMEO,
            (const char *)&milliseconds, sizeof(milliseconds));
        setsockopt(client, SOL_SOCKET, SO_SNDTIMEO,
            (const char *)&milliseconds, sizeof(milliseconds));
        char peer_address[INET_ADDRSTRLEN] = "unknown";
        (void)InetNtopA(AF_INET, &peer.sin_addr,
            peer_address, sizeof(peer_address));
        SSL *tls = NULL;
        if (secure) {
            tls = SSL_new(context);
            if (tls == NULL || SSL_set_fd(tls, (int)client) != 1) {
                log_write("TLS", "%s: TLS session setup failed", peer_address);
                SSL_free(tls);
                closesocket(client);
                continue;
            }
            if (!log_tls_accept(tls, peer_address)) {
                SSL_free(tls);
                closesocket(client);
                continue;
            }
        }

        bool local = (ntohl(peer.sin_addr.s_addr) >> 24) == 127;
        if (log_access_is_enabled()) {
            log_write("CONNECT", "%s:%u connected (%s)", peer_address,
                (unsigned)ntohs(peer.sin_port), secure ? "HTTPS" : "HTTP");
        }
        serve(server, client, local, peer_address, tls);
        if (tls != NULL) {
            /* One-way close_notify; do not block on a peer shutdown. */
            (void)SSL_shutdown(tls);
            SSL_free(tls);
        }
        closesocket(client);
        if (log_access_is_enabled()) log_write("DISCONNECT", "%s closed", peer_address);
    }
cleanup:
    log_institute_set_https_ready(false);
    InterlockedExchange(&server->tls_running,0);
    InterlockedExchange(&server->running, 0);
    if (http != INVALID_SOCKET) closesocket(http);
    if (https != INVALID_SOCKET) closesocket(https);
    if (server->stop_event != NULL) CloseHandle(server->stop_event);
    server->stop_event = NULL;
    server->listener = INVALID_SOCKET;
    SSL_CTX_free(context);
    WSACleanup();
    log_write("SERVER", "Listeners offline.");
    return result;
}

void log_server_stop(log_server *server) {
    if (server != NULL) {
        InterlockedExchange(&server->stop_requested, 1);
    }
}

void log_server_destroy(log_server *server) {
    free(server);
}

void log_server_snapshot(log_server *server, log_server_stats *stats) {
    memset(stats, 0, sizeof(*stats));
    if (server == NULL) {
        return;
    }
    stats->online =
        InterlockedCompareExchange(&server->running, 0, 0) != 0;
    stats->https_online =
        InterlockedCompareExchange(&server->tls_running,0,0) != 0;
    stats->requests = (uint64_t)InterlockedCompareExchange64(
        &server->requests, 0, 0
    );
    stats->errors = (uint64_t)InterlockedCompareExchange64(
        &server->errors, 0, 0
    );
    stats->bytes_sent = (uint64_t)InterlockedCompareExchange64(
        &server->bytes_sent, 0, 0
    );
    if (stats->online) {
        stats->uptime_seconds = (uint64_t)(time(NULL) - server->started);
    }
}
