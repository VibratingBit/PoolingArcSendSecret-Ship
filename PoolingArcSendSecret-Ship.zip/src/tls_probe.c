#include "entry.h"
#include "pool.h"
#include "tls.h"
#include "logging.h"
#include <stdarg.h>
#include <stdio.h>

/* Build-time diagnostic only: no elevated manifest, no listeners, no secrets. */
void log_write(const char *category, const char *format, ...) {
    printf("[%s] ",category);
    va_list arguments;
    va_start(arguments,format);
    vprintf(format,arguments);
    va_end(arguments);
    putchar('\n');
}

int main(int argc,char **argv) {
    if(argc!=2) {
        puts("Usage: log_tls_probe pool.conf");
        return 2;
    }
    printf("PoolingArcSendSecret %s | real-file TLS check\n",LOG_VERSION);
    log_pool_config config;
    char error[256];
    if(log_pool_load(argv[1],&config,error,sizeof(error))) {
        printf("[CONFIG] %s\n",error);
        return 2;
    }
    if(!config.https_port) {
        puts("[TLS] HTTPS disabled in configuration.");
        return 0;
    }
    printf("[TLS] Configured chain: %s\n",config.https_certificate);
    printf("[TLS] Configured key: %s\n",config.https_private_key);
    SSL_CTX *context=log_tls_context(config.https_certificate,config.https_private_key);
    if(!context) {
        puts("[TLS] HTTPS/SMTP will remain offline. HTTP can start independently.");
        return 3;
    }
    SSL_CTX_free(context);
    puts("[TLS] Real PEM certificate/key loaded and matched successfully.");
    return 0;
}
