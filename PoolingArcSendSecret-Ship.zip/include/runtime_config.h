#ifndef LOG_RUNTIME_CONFIG_H
#define LOG_RUNTIME_CONFIG_H

#include <stdbool.h>

bool log_prepare_configuration(void);

#endif
