#ifndef LOG_CONSOLE_H
#define LOG_CONSOLE_H

#include "entry.h"

int log_console_run(log_handler home, log_handler health);

#endif
