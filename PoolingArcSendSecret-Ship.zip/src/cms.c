#include "cms.h"
#include "cog.h"
#include "form.h"
#include "institute.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define PAGES "private/cms/pages.cog"
static char response_body[131073];
static char page_record[131073];
static bool route_name(const char *name){
    size_t size=strlen(name);
    if(!size||size>40)return false;
    for(size_t i=0;i<size;++i)if(!((name[i]>='a'&&name[i]<='z')|| (name[i]>='A'&&name[i]<='Z')||(name[i]>='0'&&name[i]<='9')|| name[i]=='_'||name[i]=='-'))return false;
    char lower[41];
    for(size_t i=0;i<=size;++i)lower[i]=(char)tolower((unsigned char)name[i]);
    return strcmp(lower,"maintenance")&&strcmp(lower,"institute")&& strcmp(lower,
    "api")&&strcmp(lower,"admin")&&strcmp(lower,"index")&& strcmp(lower,"account")&&strcmp(lower,
    "acccount")&&strcmp(lower,"media")&&strcmp(lower,"mail");
}
static bool lookup(const char *path,char name[41]){
    if(!strcmp(path,"/")){
        strcpy(name,"Landing");
        return true;
    }
    if(path[0]!='/'||strlen(path+1)>40)return false;
    strcpy(name,path+1);
    return route_name(name);
}
bool log_cms_page_exists(const char *path){
    char name[41];
    return lookup(path,name)&&!log_cog_get(PAGES,"pages",name,page_record, sizeof(page_record));
}
int log_cms_field(const char *path,const char *field,char *out,size_t capacity){
    char name[41];
    if(!lookup(path,name)||log_cog_get(PAGES,"pages",name,page_record, sizeof(page_record)))return -1;
    return log_form_get(page_record,strlen(page_record),field,out,capacity);
}
static void reply(log_response *out,int status,const char *text){
    out->status=status;
    out->content_type="application/json; charset=utf-8";
    out->body=text;
    out->body_length=strlen(text);
}
typedef struct{
    size_t used;
    bool first;
}
listing;
static int list_page(const char *key,const char *value,void *context){
    (void)value;
    listing *list=context;
    if(!strcmp(key,"Landing")||!strcmp(key,"maintenance"))return 0;
    if(!route_name(key))return 0;
    int n=snprintf(response_body+list->used,sizeof(response_body)-list->used,
    ",{\"path\":\"/%s\",\"label\":\"%s\"}",key,key);
    if(n<0||(size_t)n>=sizeof(response_body)-list->used)return -1;
    list->used+=(size_t)n;
    return 0;
}
bool log_cms_handle(const log_request *r,log_response *out){
    if(!log_institute_admin_exists() && (!strcmp(r->path,"/api/routes")||!strcmp(r->path,
    "/api/pages"))) {
        reply(out,503,"{\"error\":\"Site not live\"}");
        return true;
    }
    if(!strcmp(r->path,"/api/routes")&&!strcmp(r->method,"GET")){
        strcpy(response_body,"[{\"path\":\"/maintenance\",\"label\":\"Maintenance\"}");
        strcat(response_body, ",{\"path\":\"/Media\",\"label\":\"Media\"}");
        if(log_institute_role(r,false)==3) strcat(response_body,",{\"path\":\"/Mail\",\"label\":\"Mail\"}");
        listing list={
            strlen(response_body),false
        };
        if(log_cog_scan(PAGES,"pages",list_page,&list)){
            reply(out,500,"{\"error\":\"Cannot load route table\"}");
            return true;
        }
        strcat(response_body,"]");
        reply(out,200,response_body);
        return true;
    }
    if(strcmp(r->path,"/api/pages"))return false;
    char route[41];
    const char *body=r->body;
    size_t length=r->body_length;
    if(!strcmp(r->method,"GET")){
        body=r->query;
        length=strlen(r->query);
    }
    if(log_form_get(body,length,"route",route,sizeof(route))||(!route_name(route)&&strcmp(route,
    "maintenance"))){
        reply(out,400,"{\"error\":\"Use a route name with 1-40 letters, digits, hyphens or underscores\"}");
        return true;
    }
    if(!strcmp(r->method,"GET")){
        int result=log_cog_get(PAGES,"pages",route,page_record,sizeof(page_record));
        if(result){
            reply(out,result==1?404:500,"{\"error\":\"Page unavailable\"}");
            return true;
        }
        out->status=200;
        out->content_type="text/plain; charset=utf-8";
        out->body=page_record;
        out->body_length=strlen(page_record);
        return true;
    }
    if(strcmp(r->method,"POST")){
        reply(out,405,"{\"error\":\"Method not allowed\"}");
        return true;
    }
    if(log_institute_role(r,true)<2){
        reply(out,403,"{\"error\":\"Administrator/moderator session and CSRF token required\"}");
        return true;
    }
    char action[16];
    if(log_form_get(body,length,"action",action,sizeof(action))){
        reply(out,400,"{\"error\":\"Action required\"}");
        return true;
    }
    if(!strcmp(route,"maintenance")&&strcmp(action,"save")) {
        reply(out,403,"{\"error\":\"Built-in route is protected\"}");
        return true;
    }
    if(!strcmp(action,"delete")){
        int result=log_cog_remove(PAGES,"pages",route);
        reply(out,result?404:200,result?"{\"error\":\"Page not found\"}":"{\"ok\":true}");
        return true;
    }
    char heading[257],description[1025],content[10001];
    if((strcmp(action,"create")&&strcmp(action,"save"))||length>131072|| log_form_get(body,
    length,"heading",heading,sizeof(heading))|| log_form_get(body,length,"description",
    description,sizeof(description))|| log_form_get(body,length,"content",content,
    sizeof(content))){
        reply(out,400,"{\"error\":\"Invalid page fields\"}");
        return true;
    }
    memcpy(page_record,body,length);
    page_record[length]=0;
    int result=log_cog_put(PAGES,"pages",route,page_record,!strcmp(action,"create"));
    reply(out,result==1?409:result?500:200, result?"{\"error\":\"Page conflict or storage failure\"}":"{\"ok\":true}");
    return true;
}
