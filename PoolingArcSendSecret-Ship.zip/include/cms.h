#ifndef LOG_CMS_H
#define LOG_CMS_H
#include "entry.h"
bool log_cms_handle(const log_request *request,log_response *response);
int log_cms_field(const char *path,const char *field,char *out,size_t capacity);
bool log_cms_page_exists(const char *path);
#endif
