#ifndef LOG_ENTRY_H
#define LOG_ENTRY_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define LOG_VERSION "0.1.5"
#define LOG_MAX_REQUEST 16384U
#define LOG_MAX_BODY 1048576U

typedef struct log_server log_server;

typedef struct {
    char method[12];
    char path[1024];
    const char *body;
    size_t body_length;
    char host[256];
    char origin[320];
    char cookie[2048];
    char csrf[96];
    char peer[64];
    char query[1024];
    char range[128];
    bool secure;
} log_request;

typedef struct {
    int status;
    const char *content_type;
    const char *body;
    size_t body_length;
    char cookie_header[512];
} log_response;

typedef void (*log_handler)(
    const log_request *request,
    log_response *response
);

log_server *log_server_create(void);

bool log_server_route(
    log_server *server,
    const char *method,
    const char *path,
    log_handler handler
);

bool log_server_enable_tls(
    log_server *server,
    const char *bind_address,
    uint16_t port,
    const char *certificate,
    const char *private_key
);

int log_server_run(
    log_server *server,
    const char *host,
    uint16_t port
);

typedef struct {
    bool online;
    bool https_online;
    uint64_t requests;
    uint64_t errors;
    uint64_t bytes_sent;
    uint64_t uptime_seconds;
} log_server_stats;

void log_server_snapshot(log_server *server, log_server_stats *stats);
void log_server_stop(log_server *server);
void log_server_destroy(log_server *server);

/* Per-user, local Windows server-process control. */
int log_control(const char *action);

#endif
