#include "console.h"
#include "console_commands.h"
#include "logging.h"
#include "pool.h"
#include "runtime_config.h"
#include "tls.h"
#include "terminal.h"
#include "ports.h"
#include "assets.h"
#include "firewall.h"
#include "dns.h"
#include "institute.h"
#include "smtp.h"
#include "mail.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdio.h>
#include <string.h>

/* Only the command thread owns worker and server lifetime. The HTTP thread
   owns listeners and request processing. Cross-thread counters are atomic. */
typedef struct {
    log_server *server;
    HANDLE worker;
    log_pool_config config;
    log_handler home;
    log_handler health;
} console_app;

static log_pool_config active_network(console_app *app,const log_server_stats *stats) {
    log_pool_config active=app->config;
    if(!stats->https_online) active.https_port=0;
    if(!log_smtp_running()) active.smtp_enabled=0;
    return active;
}

static DWORD WINAPI server_worker(void *argument) {
    console_app *app = argument;
    int result = log_server_run(
        app->server, app->config.http_bind, app->config.http_port
    );
    if (result != 0) {
        log_write("ERROR", "Server stopped after an error; see the preceding TLS/network diagnostic.");
    }
    return (DWORD)result;
}

static void reap_worker(console_app *app) {
    if (app->worker != NULL &&
        WaitForSingleObject(app->worker, 0) == WAIT_OBJECT_0) {
        CloseHandle(app->worker);
        app->worker = NULL;
        log_ports_close();
        log_smtp_stop();
        log_dns_stop();
        log_firewall_close();
        /* Keep final counters available while offline. */
    }
}

static bool start_server(console_app *app) {
    char error[256];
    reap_worker(app);
    if (app->worker != NULL) {
        log_write("SERVER", "Already running.");
        return false;
    }
    log_pool_config next;
    if (log_pool_load("pool.conf", &next, error, sizeof(error))) {
        log_write("CONFIG", "%s", error);
        return false;
    }

    log_server *server = log_server_create();
    if (server == NULL) {
        log_write("ERROR", "Cannot allocate server.");
        return false;
    }
    if (!log_server_route(server, "GET", "/", app->home) ||
        !log_server_route(server, "GET", "/api/health", app->health)) {
        log_server_destroy(server);
        log_write("ERROR", "Route registration failed.");
        return false;
    }

    const char *assets[] = {
        "/index.html", "/admin", "/maintenance", "/maintenance/",
        "/Institute", "/Institute/", "/mirror-logo.png",
        "/design.css", "/design.js", "/favicon.ico"
    };
    for (size_t i = 0; i < sizeof(assets) / sizeof(assets[0]); ++i) {
        if (!log_server_route(server, "GET", assets[i], app->home)) {
            log_server_destroy(server);
            return false;
        }
    }
    if (!log_server_route(server, "POST", "/api/echo", app->health)) {
        log_server_destroy(server);
        return false;
    }
    if (next.https_port != 0 &&
        !log_server_enable_tls(
            server,
            next.https_bind[0] ? next.https_bind : next.http_bind,
            next.https_port,
            next.https_certificate,
            next.https_private_key
        )) {
        log_server_destroy(server);
        log_write("CONFIG", "Invalid HTTPS configuration.");
        return false;
    }
    log_server_destroy(app->server);
    app->server = server;
    app->config = next;
    log_assets_configure(&next);
    app->worker = CreateThread(NULL, 0, server_worker, app, 0, NULL);
    if (app->worker == NULL) {
        log_write("ERROR", "Cannot create HTTP worker.");
        return false;
    }
    /* Wait briefly for actual listener readiness rather than claiming that
       CreateThread alone means the port is serving requests. */
    for (unsigned attempt = 0; attempt < 100; ++attempt) {
        log_server_stats stats;
        log_server_snapshot(app->server, &stats);
        if (stats.online) {
            if (stats.https_online && !log_smtp_start(&app->config)) {
                log_write("SMTP","Inbound service could not start; port 25 not mapped");
            }
            if (app->config.smtp_enabled && !stats.https_online)
                log_write("SMTP","Offline until the TLS certificate/key pair is available.");
            log_pool_config active=active_network(app,&stats);
            if (app->config.firewall_enabled) {
                log_firewall_open(&active, log_smtp_running());
            }
            if (!log_dns_start(&app->config)) {
                log_write("DNS", "Local DNS startup failed.");
            }
            if (active.upnp_enabled) log_ports_open(&active);
            return true;
        }
        if (WaitForSingleObject(app->worker, 50) == WAIT_OBJECT_0) {
            reap_worker(app);
            return false;
        }
    }
    log_write("SERVER", "Still starting. Use status to check readiness.");
    return true;
}

static void stop_server(console_app *app) {
    log_ports_close();
    log_smtp_stop();
    log_dns_stop();
    log_firewall_close();
    reap_worker(app);
    if (app->worker == NULL) {
        log_write("SERVER", "Offline.");
        return;
    }
    log_write("SERVER", "Stopping; waiting for active request to finish...");
    log_server_stop(app->server);
    WaitForSingleObject(app->worker, INFINITE);
    reap_worker(app);
    log_write("SERVER", "Offline. Type start to resume.");
}

static void print_status(console_app *app, bool traffic) {
    log_server_stats stats;
    reap_worker(app);
    log_server_snapshot(app->server, &stats);
    if (!traffic) {
        log_write("STATUS", "%s | http://%s:%u | request logging %s",
            stats.online ? "ONLINE" : "OFFLINE",
            app->config.http_bind,
            (unsigned)app->config.http_port,
            log_access_is_enabled() ? "on" : "off");
        log_write("STATUS","HTTPS %s | SMTP %s",
            stats.https_online?"ONLINE":"OFFLINE",
            log_smtp_running()?"ONLINE":"OFFLINE");
    }
    log_write("TRAFFIC", "Requests=%llu Errors=%llu Bytes=%llu Uptime=%llus",
        (unsigned long long)stats.requests,
        (unsigned long long)stats.errors,
        (unsigned long long)stats.bytes_sent,
        (unsigned long long)stats.uptime_seconds);
}

static void print_help(void) {
    const char *commands[] = {
        "help | start | shutdown/stop | restart/reload | status | traffic",
        "ports open | ports close | ports status",
        "config | logs on | logs off | /wipe | exit/quit",
        "Scroll logs: mouse wheel, PgUp/PgDn. Ctrl+End resumes live follow.",
        "Restart reloads pool.conf. /wipe clears screen history, not metrics."
    };
    for (size_t i = 0; i < sizeof(commands) / sizeof(commands[0]); ++i) {
        log_write("HELP", "%s", commands[i]);
    }
}

int log_console_run(log_handler home, log_handler health) {
    console_app app = {0};
    char input[256];
    app.home = home;
    app.health = health;
    setvbuf(stdout, NULL, _IONBF, 0);
    SetConsoleTitleW(L"PoolingArcSendSecret - Server Console");
    puts("PoolingArcSendSecret | native C server console");

    if (!log_prepare_configuration()) {
        puts("Missing pool.conf beside the EXE. Run log.bat. Press Enter to close.");
        (void)fgets(input, sizeof(input), stdin);
        return 1;
    }

    log_terminal_init();
    log_write("BUILD","PoolingArcSendSecret " LOG_VERSION " | HTTP/TLS startup repair");
    if (!log_institute_init() || !log_mail_init()) {
        log_write("INSTITUTE", "Private account/mail storage initialization failed.");
        log_terminal_close();
        puts("Press Enter to close.");
        (void)fgets(input,sizeof(input),stdin);
        return 1;
    }
    if (!log_institute_admin_exists())
        log_write("INSTITUTE", "Use Go Live with private/institute/setup.token");
    print_help();
    start_server(&app);
    bool exiting = false;
    while (!exiting) {
        reap_worker(&app);
        if (!log_terminal_read(input, sizeof(input))) {
            break;
        }
        switch (log_command_parse(input)) {
            case LOG_COMMAND_EMPTY:
                break;
            case LOG_COMMAND_PORTS_OPEN: {
                log_server_stats stats;
                log_server_snapshot(app.server, &stats);
                if (stats.online) {
                    log_pool_config active=active_network(&app,&stats);
                    log_ports_open(&active);
                }
                else log_write("UPNP", "Start the server before opening ports.");
                break;
            }
            case LOG_COMMAND_PORTS_CLOSE:
                log_ports_close();
                break;
            case LOG_COMMAND_PORTS_STATUS:
                log_ports_status();
                break;
            case LOG_COMMAND_WIPE:
                log_terminal_wipe();
                break;
            case LOG_COMMAND_HELP:
                print_help();
                break;
            case LOG_COMMAND_START:
                start_server(&app);
                break;
            case LOG_COMMAND_STOP:
                stop_server(&app);
                break;
            case LOG_COMMAND_RESTART:
                stop_server(&app);
                start_server(&app);
                break;
            case LOG_COMMAND_STATUS:
                print_status(&app, false);
                break;
            case LOG_COMMAND_TRAFFIC:
                print_status(&app, true);
                break;
            case LOG_COMMAND_CONFIG: {
                wchar_t directory[32768];
                if (GetCurrentDirectoryW(32768, directory) != 0) {
                    log_write("CONFIG", "Configuration: %ls\\pool.conf", directory);
                }
                log_write(
                    "CONFIG", "HTTP bind: %s | HTTP port: %u | HTTPS port: %u",
                    app.config.http_bind,
                    (unsigned)app.config.http_port,
                    (unsigned)app.config.https_port
                );
                break;
            }
            case LOG_COMMAND_LOGS_ON:
                log_access_enabled(true);
                log_write("LOGGING", "Request logs enabled.");
                break;
            case LOG_COMMAND_LOGS_OFF:
                log_access_enabled(false);
                log_write("LOGGING", "Request logs disabled; metrics continue.");
                break;
            case LOG_COMMAND_EXIT:
                exiting = true;
                break;
            default:
                log_write("COMMAND", "Unknown command. Type help.");
                break;
        }
    }
    stop_server(&app);
    log_server_destroy(app.server);
    log_terminal_close();
    puts("Goodbye.");
    return 0;
}
