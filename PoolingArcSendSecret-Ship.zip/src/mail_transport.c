#include "mail.h"
#include <stdio.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <windns.h>
#include <wincrypt.h>
#include <openssl/ssl.h>
#include <openssl/rand.h>
#include <openssl/x509.h>
#include <stdlib.h>
typedef struct {
    SOCKET socket;
    SSL *tls;
    ULONGLONG deadline;
}
outbound;
static bool write_all(outbound *io, const char *text) {
    size_t left = strlen(text);
    while (left && GetTickCount64() < io->deadline) {
        int chunk = (int)(left > 4096 ? 4096 : left);
        int sent = io->tls ? SSL_write(io->tls, text, chunk) : send(io->socket,
        text, chunk, 0);
        if (sent <= 0) return false;
        text += sent;
        left -= (size_t)sent;
    }
    return left == 0;
}
static int reply(outbound *io, bool *starttls, bool *eightbit) {
    int code = -1;
    for (unsigned lines = 0; lines < 64; ++lines) {
        char line[1024];
        size_t used = 0;
        while (used < sizeof(line) - 1 && GetTickCount64() < io->deadline) {
            int count = io->tls ? SSL_read(io->tls, line + used, 1) : recv(io->socket,
            line + used, 1, 0);
            if (count != 1) return -1;
            if (line[used++] == '\n') break;
        }
        line[used] = 0;
        if (used < 5 || line[used - 1] != '\n' || line[0] < '0' || line[0] > '9' || line[1] < '0' || line[1] > '9' || line[2] < '0' || line[2] > '9') return -1;
        int current = (line[0] - '0') * 100 + (line[1] - '0') * 10 + line[2] - '0';
        if (code >= 0 && code != current) return -1;
        code = current;
        if (starttls && !_strnicmp(line + 4, "STARTTLS", 8)) *starttls = true;
        if (eightbit && !_strnicmp(line + 4, "8BITMIME", 8)) *eightbit = true;
        if (line[3] == ' ') return code;
        if (line[3] != '-') return -1;
    }
    return -1;
}
static SOCKET connect_mx(const char *host, ULONGLONG deadline) {
    struct addrinfo hints = {
        0
    }, *addresses = NULL;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_family = AF_UNSPEC;
    if (getaddrinfo(host, "25", &hints, &addresses)) return INVALID_SOCKET;
    SOCKET connected = INVALID_SOCKET;
    for (struct addrinfo *a = addresses; a && GetTickCount64() < deadline; a = a->ai_next) {
        SOCKET candidate = socket(a->ai_family, SOCK_STREAM, IPPROTO_TCP);
        if (candidate == INVALID_SOCKET) continue;
        u_long nonblocking = 1;
        ioctlsocket(candidate, (long)FIONBIO, &nonblocking);
        int result = connect(candidate, a->ai_addr, (int)a->ai_addrlen);
        if (result && WSAGetLastError() == WSAEWOULDBLOCK) {
            fd_set ready;
            FD_ZERO(&ready);
            FD_SET(candidate, &ready);
            struct timeval timeout = {
                4, 0
            };
            result = select(0, NULL, &ready, NULL, &timeout);
            int error = 1, size = sizeof(error);
            if (result > 0) getsockopt(candidate, SOL_SOCKET, SO_ERROR, (char *)&error,
            &size);
            result = error ? -1 : 0;
        }
        if (!result) {
            nonblocking = 0;
            ioctlsocket(candidate, (long)FIONBIO, &nonblocking);
            DWORD timeout = 4000;
            setsockopt(candidate, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout,
            sizeof(timeout));
            setsockopt(candidate, SOL_SOCKET, SO_SNDTIMEO, (const char *)&timeout,
            sizeof(timeout));
            connected = candidate;
            break;
        }
        closesocket(candidate);
    }
    freeaddrinfo(addresses);
    return connected;
}
static void trust_windows(SSL_CTX *context) {
    const char *names[] = {
        "ROOT", "CA"
    };
    X509_STORE *trust = SSL_CTX_get_cert_store(context);
    for (unsigned i = 0; i < 2; ++i) {
        HCERTSTORE store = CertOpenSystemStoreA(0, names[i]);
        if (!store) continue;
        PCCERT_CONTEXT certificate = NULL;
        while ((certificate = CertEnumCertificatesInStore(store, certificate))) {
            const unsigned char *der = certificate->pbCertEncoded;
            X509 *x509 = d2i_X509(NULL, &der, (long)certificate->cbCertEncoded);
            if (x509) {
                X509_STORE_add_cert(trust, x509);
                X509_free(x509);
            }
        }
        CertCloseStore(store, 0);
    }
}
static bool deliver(const char *mx, const char *hostname, const char *from, const char *to,
const char *message, char *error, size_t capacity, bool *data_started) {
    *data_started=false;
    outbound io = {
        INVALID_SOCKET, NULL, GetTickCount64() + 30000
    };
    io.socket = connect_mx(mx, io.deadline);
    if (io.socket == INVALID_SOCKET) {
        snprintf(error, capacity, "Cannot connect to destination TCP 25; message retained in Outbox.");
        return false;
    }
    SSL_CTX *context = SSL_CTX_new(TLS_client_method());
    bool accepted = false, starttls = false, eightbit = false;
    char command[640];
    int code = -1;
    if (!context || reply(&io, NULL, NULL) != 220) goto done;
    snprintf(command, sizeof(command), "EHLO %s\r\n", hostname);
    if (!write_all(&io, command) || reply(&io, &starttls, NULL) != 250) goto done;
    if (!starttls) {
        snprintf(error, capacity, "Destination has no STARTTLS. Unencrypted delivery refused; retained in Outbox.");
        goto done;
    }
    if (!write_all(&io, "STARTTLS\r\n") || reply(&io, NULL, NULL) != 220) goto done;
    SSL_CTX_set_min_proto_version(context, TLS1_2_VERSION);
    SSL_CTX_set_verify(context, SSL_VERIFY_PEER, NULL);
    trust_windows(context);
    io.tls = SSL_new(context);
    if (!io.tls || SSL_set_fd(io.tls, (int)io.socket) != 1 || SSL_set_tlsext_host_name(io.tls,
    mx) != 1 || SSL_set1_host(io.tls, mx) != 1 || SSL_connect(io.tls) != 1) {
        snprintf(error, capacity, "Destination TLS verification failed; retained in Outbox.");
        goto done;
    }
    if (!write_all(&io, command) || reply(&io, NULL, &eightbit) != 250) goto done;
    bool high = false;
    for (const unsigned char *p = (const unsigned char *)message; *p; ++p) high |= *p > 127;
    if (high && !eightbit) {
        snprintf(error, capacity, "Destination does not support 8BITMIME; retained in Outbox.");
        goto done;
    }
    snprintf(command, sizeof(command), "MAIL FROM:<%s>%s\r\n", from, high ? " BODY=8BITMIME" : "");
    if (!write_all(&io, command) || reply(&io, NULL, NULL) != 250) goto done;
    snprintf(command, sizeof(command), "RCPT TO:<%s>\r\n", to);
    if (!write_all(&io, command)) goto done;
    code = reply(&io, NULL, NULL);
    if (code != 250 && code != 251) goto done;
    if (!write_all(&io, "DATA\r\n") || reply(&io, NULL, NULL) != 354) goto done;
    *data_started=true;
    /* Dot-stuff lines; the stored RFC 5322 source remains unchanged. */ const char *line = message;
    while (*line) {
        const char *end = strstr(line, "\r\n");
        if (!end || (size_t)(end - line) > 998) goto done;
        char data[1004];
        size_t used = 0;
        if (*line == '.') data[used++] = '.';
        size_t length = (size_t)(end - line) + 2;
        memcpy(data + used, line, length);
        data[used + length] = 0;
        if (!write_all(&io, data)) goto done;
        line = end + 2;
    }
    if (!write_all(&io, ".\r\n")) goto done;
    code = reply(&io, NULL, NULL);
    accepted = code == 250;
    if (!accepted) snprintf(error, capacity, "Destination did not confirm acceptance (SMTP %d). Retained in Outbox; check before resending.",
    code);
    if (accepted) write_all(&io, "QUIT\r\n");
    done: if (io.tls) SSL_free(io.tls);
    SSL_CTX_free(context);
    closesocket(io.socket);
    return accepted;
}
bool log_mail_transport(const char *hostname, const char *from, const char *to,
const char *message, char *error, size_t capacity) {
    (void)hostname;
    const char *domain = strchr(to, '@') + 1;
    PDNS_RECORD records = NULL;
    DNS_STATUS result = DnsQuery_A(domain, DNS_TYPE_MX, DNS_QUERY_STANDARD, NULL,
    &records, NULL);
    char hosts[16][256];
    unsigned short preferences[16];
    unsigned count = 0;
    if (!result) {
        for (PDNS_RECORD record = records; record && count < 16; record = record->pNext) {
            if (record->wType != DNS_TYPE_MX || !record->Data.MX.pNameExchange) continue;
            const char *host = record->Data.MX.pNameExchange;
            if (!strcmp(host, ".") || !*host) {
                DnsRecordListFree(records, DnsFreeRecordList);
                snprintf(error, capacity, "Recipient domain explicitly accepts no email (null MX).");
                return false;
            }
            snprintf(hosts[count], sizeof(hosts[count]), "%s", host);
            size_t length = strlen(hosts[count]);
            if (length && hosts[count][length - 1] == '.') hosts[count][length - 1] = 0;
            preferences[count++] = record->Data.MX.wPreference;
        }
    }
    if (records) DnsRecordListFree(records, DnsFreeRecordList);
    if (!count && (result == DNS_INFO_NO_RECORDS || !result)) {
        snprintf(hosts[0], sizeof(hosts[0]), "%s", domain);
        preferences[0] = 0;
        count = 1;
    }
    if (!count) {
        snprintf(error, capacity, "Recipient MX lookup failed (%ld); retained in Outbox.",
        (long)result);
        return false;
    }
    for (unsigned i = 0; i < count; ++i) {
        unsigned best = i;
        for (unsigned j = i + 1; j < count; ++j) if (preferences[j] < preferences[best]) best = j;
        char swap[256];
        strcpy(swap, hosts[i]);
        strcpy(hosts[i], hosts[best]);
        strcpy(hosts[best], swap);
        unsigned short preference = preferences[i];
        preferences[i] = preferences[best];
        preferences[best] = preference;
    }
    /* Spread equal-preference MX choices; never retry after DATA started. */ for(unsigned i=0;i<count;++i) {
        for(unsigned j=i+1;j<count && preferences[j]==preferences[i];++j) {
            unsigned char coin=0;
            if(RAND_bytes(&coin,1)==1 && (coin&1)) {
                char swap[256];
                strcpy(swap,hosts[i]);
                strcpy(hosts[i],hosts[j]);
                strcpy(hosts[j],swap);
            }
        }
    }
    for(unsigned i=0;i<count && i<3;++i) {
        bool data_started=false;
        if(deliver(hosts[i],strchr(from,'@')+1,from,to,message,error,capacity,
        &data_started)) return true;
        if(data_started) return false;
    }
    return false;
}
#else
bool log_mail_transport(const char *hostname, const char *from, const char *to,
const char *message, char *error, size_t capacity) {
    (void)hostname;
    (void)from;
    (void)to;
    (void)message;
    snprintf(error, capacity, "Direct-MX delivery is available in the Windows build.");
    return false;
}
#endif
