#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "firewall.h"
#include "logging.h"
#include <stdio.h>
#include <wchar.h>

static unsigned opened[3];
static unsigned opened_count;

static bool firewall_rule(unsigned port, bool add) {
    wchar_t netsh[MAX_PATH];
    wchar_t program[32768];
    wchar_t command[34000];
    UINT length = GetSystemDirectoryW(netsh, MAX_PATH);
    if (!length || length + 11 >= MAX_PATH) return false;
    wcscat(netsh, L"\\netsh.exe");
    DWORD size = GetModuleFileNameW(NULL, program, 32768);
    if (!size || size >= 32768) return false;
    if (add) {
        swprintf(command, 34000,
            L"\"%ls\" advfirewall firewall add rule "
            L"name=\"PoolingArcSendSecret TCP-%u\" "
            L"dir=in action=allow enable=yes profile=any protocol=TCP "
            L"localport=%u program=\"%ls\"", netsh, port, port, program);
    } else {
        swprintf(command, 34000,
            L"\"%ls\" advfirewall firewall delete rule "
            L"name=\"PoolingArcSendSecret TCP-%u\" program=\"%ls\"",
            netsh, port, program);
    }
    STARTUPINFOW startup = {0};
    PROCESS_INFORMATION process = {0};
    startup.cb = sizeof(startup);
    if (!CreateProcessW(netsh, command, NULL, NULL, FALSE,
            CREATE_NO_WINDOW, NULL, NULL, &startup, &process)) return false;
    WaitForSingleObject(process.hProcess, INFINITE);
    DWORD result = 1;
    GetExitCodeProcess(process.hProcess, &result);
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    return result == 0;
}

void log_firewall_close(void) {
    for (unsigned i = 0; i < opened_count; ++i) {
        if (!firewall_rule(opened[i], false)) {
            log_write("FIREWALL", "Could not remove own TCP-%u rule", opened[i]);
        }
    }
    opened_count = 0;
}

bool log_firewall_open(const log_pool_config *config, bool smtp_ready) {
    log_firewall_close();
    unsigned ports[3] = {config->http_port, config->https_port,
        smtp_ready ? config->smtp_port : 0};
    bool result = true;
    for (unsigned i = 0; i < 3; ++i) {
        if (!ports[i]) continue;
        bool duplicate = false;
        for (unsigned j = 0; j < i; ++j) duplicate |= ports[i] == ports[j];
        if (duplicate) continue;
        /* Replace only our own named, program-scoped rule. */
        (void)firewall_rule(ports[i], false);
        if (firewall_rule(ports[i], true)) {
            opened[opened_count++] = ports[i];
            log_write("FIREWALL", "Allowed TCP %u for this executable", ports[i]);
        } else {
            result = false;
            log_write("FIREWALL", "TCP %u rule failed; elevation may be needed",
                ports[i]);
        }
    }
    return result;
}
