#include "cog.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){
    const char *p="cog-test.cog";remove(p);char value[128];
    assert(log_cog_get(p,"members","Sshhm",value,sizeof(value))==1);
    assert(log_cog_put(p,"members","Sshhm","salted-hash\nnot plaintext",true)==0);
    assert(log_cog_put(p,"members","Sshhm","duplicate",true)==1);
    assert(log_cog_get(p,"members","Sshhm",value,sizeof(value))==0);
    assert(!strcmp(value,"salted-hash\nnot plaintext"));
    assert(log_cog_put(p,"members","Sshhm","updated",false)==0);
    assert(log_cog_get(p,"wrong_table","Sshhm",value,sizeof(value))==-1);
    assert(log_cog_remove(p,"members","Sshhm")==0);
    assert(log_cog_get(p,"members","Sshhm",value,sizeof(value))==1);
    remove(p);return 0;
}
