#ifndef LOG_MEDIA_H
#define LOG_MEDIA_H
#include "entry.h"
bool log_media_handle(const log_request *request, log_response *response);
void log_media_free(void);
#endif
