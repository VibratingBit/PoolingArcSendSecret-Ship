#ifndef LOG_JSON_H
#define LOG_JSON_H
#include <stdbool.h>
#include <stddef.h>
typedef struct {
    char *data;
    size_t used;
    size_t capacity;
    bool failed;
} log_json;
void log_json_text(log_json *json, const char *text);
void log_json_string(log_json *json, const char *text);
#endif
