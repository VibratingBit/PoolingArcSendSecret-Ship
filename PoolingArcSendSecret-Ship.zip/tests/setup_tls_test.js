'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const button = {disabled:false,addEventListener() { throw new Error('Setup must stay disabled without TLS'); }};
const form = {hidden:true};
const message = {textContent:''};
const nodes = {'begin-setup':button,'setup-form':form,'setup-status':message};
const context = {
  fetch:async () => ({ok:true,json:async () => ({live:false,https:false})}),
  document:{body:{dataset:{page:'setup'}},getElementById:id => nodes[id]},
  location:{replace() { throw new Error('Must not redirect to offline HTTPS'); }}
};
(async () => {
  await vm.runInNewContext(fs.readFileSync('entry/design.js','utf8'),context);
  assert.equal(button.disabled,true);
  assert.equal(form.hidden,true);
  assert.match(message.textContent,/HTTPS needs your certificate files/);
  console.log('Missing-TLS setup remains disabled, HTTP page stays available');
})().catch(error => { console.error(error); process.exitCode=1; });
