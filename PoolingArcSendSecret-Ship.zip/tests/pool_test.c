#include "pool.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
    const char *path = "pool_test_input.conf";
    char error[256];
    log_pool_config configuration;
    FILE *file = fopen(path, "wb");
    assert(file != NULL);

    fputs(
        ";BIND = 127.0.0.1\n"
        ";DATA = Launch/private\n"
        "http_bind ;{BIND}\n"
        "log_file ${DATA}/pool.log\n"
        "http_port 8090\n",
        file
    );
    fclose(file);

    assert(
        log_pool_load(
            path, &configuration, error, sizeof(error)
        ) == 0
    );
    assert(strcmp(configuration.http_bind, "127.0.0.1") == 0);
    assert(
        strcmp(
            configuration.log_file,
            "Launch/private/pool.log"
        ) == 0
    );
    assert(configuration.http_port == 8090);

    file = fopen(path, "wb");
    assert(file != NULL);
    fputs("http_bind 127.0.0.1\nupnp true\nupnp_lease 3600\n", file);
    fclose(file);
    assert(
        log_pool_load(path, &configuration, error, sizeof(error)) == 0
    );
    assert(configuration.http_port == 80);
    assert(configuration.upnp_enabled == 1);
    assert(configuration.upnp_lease == 3600);

    file = fopen(path, "wb");
    assert(file != NULL);
    fputs("http_port 99999\n", file);
    fclose(file);
    assert(
        log_pool_load(
            path, &configuration, error, sizeof(error)
        ) != 0
    );

    file = fopen(path, "wb");
    assert(file != NULL);
    fputs("http_bind ${UNDEFINED}\n", file);
    fclose(file);
    assert(
        log_pool_load(
            path, &configuration, error, sizeof(error)
        ) != 0
    );

    remove(path);
    puts("pool config tests passed");
    return 0;
}
