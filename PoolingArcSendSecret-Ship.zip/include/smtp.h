#ifndef LOG_SMTP_H
#define LOG_SMTP_H
#include "pool.h"
bool log_smtp_start(const log_pool_config *config);
void log_smtp_stop(void);
bool log_smtp_running(void);
#endif
