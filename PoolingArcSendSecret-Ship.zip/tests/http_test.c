#include "http.h"

#include <assert.h>
#include <string.h>

int main(void) {
    char valid[] =
        "GET /api/health?verbose=1 HTTP/1.1\r\n"
        "Host: localhost\r\n"
        "\r\n";
    log_request request;

    assert(log_http_parse(valid, strlen(valid), &request) == 0);
    assert(strcmp(request.method, "GET") == 0);
    assert(strcmp(request.path, "/api/health?verbose=1") == 0);

    char invalid[] =
        "GET / HTTP/1.1\n"
        "Host: localhost\n\n";
    assert(log_http_parse(invalid, strlen(invalid), &request) != 0);

    char duplicated[] =
        "POST / HTTP/1.1\r\n"
        "Host: localhost\r\n"
        "Content-Length: 0\r\n"
        "Content-Length: 0\r\n"
        "\r\n";
    assert(log_http_parse(duplicated, strlen(duplicated), &request) == 400);

    /* A non-null-terminated network buffer must remain bounded. */
    char bounded[] = {'G', 'E', 'T', ' ', '/', ' ', 'H'};
    assert(log_http_parse(bounded, sizeof(bounded), &request) == 400);

    char browser[] =
        "GET /maintenance HTTP/1.1\r\n"
        "Host: delicacy.diy\r\n"
        "Cookie: theme=slate; accent=ice\r\n"
        "Sec-Fetch-Mode: navigate\r\n"
        "Accept: text/html,application/xhtml+xml\r\n\r\n";
    assert(log_http_parse(browser, strlen(browser), &request) == 0);
    assert(strcmp(request.path, "/maintenance") == 0);
    assert(strcmp(request.host, "delicacy.diy") == 0);
    assert(strcmp(request.cookie, "theme=slate; accent=ice") == 0);
    char range[] = "GET /Media/file?name=sample.png HTTP/1.1\r\n"
        "Host: localhost\r\nRange: bytes=0-3\r\n\r\n";
    assert(log_http_parse(range,strlen(range),&request)==0);
    assert(!strcmp(request.range,"bytes=0-3"));
    char duplicate_range[] = "GET /Media/file HTTP/1.1\r\n"
        "Host: localhost\r\nRange: bytes=0-1\r\nRange: bytes=2-3\r\n\r\n";
    assert(log_http_parse(duplicate_range,strlen(duplicate_range),&request)==400);
    return 0;
}
