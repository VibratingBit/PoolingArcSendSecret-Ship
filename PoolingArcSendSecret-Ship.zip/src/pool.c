#include "pool.h"

#include <ctype.h>
#include <stdbool.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LOG_MAX_VARIABLES 64

typedef struct {
    char name[64];
    char value[1024];
} pool_variable;

static void trim(char *text) {
    char *start = text;
    while (*start == ' ' || *start == '\t') {
        ++start;
    }

    if (start != text) {
        memmove(text, start, strlen(start) + 1);
    }

    size_t length = strlen(text);
    while (length > 0 &&
           strchr(" \t\n\r", text[length - 1]) != NULL) {
        text[--length] = '\0';
    }
}

static int copy_checked(
    char *destination,
    size_t capacity,
    const char *value
) {
    size_t length = strlen(value);
    if (length >= capacity) {
        return -1;
    }

    memcpy(destination, value, length + 1);
    return 0;
}

static int expand_variables(
    const char *source,
    char *output,
    size_t capacity,
    const pool_variable *variables,
    size_t count
) {
    size_t used = 0;

    while (*source != '\0') {
        bool reference =
            (source[0] == ';' || source[0] == '$') &&
            source[1] == '{';

        if (!reference) {
            if (used + 1 >= capacity) {
                return -1;
            }
            output[used++] = *source++;
            continue;
        }

        const char *end = strchr(source + 2, '}');
        if (end == NULL) {
            return -1;
        }

        size_t key_length = (size_t)(end - source - 2);
        const char *value = NULL;

        for (size_t index = 0; index < count; ++index) {
            if (strlen(variables[index].name) == key_length &&
                memcmp(
                    variables[index].name,
                    source + 2,
                    key_length
                ) == 0) {
                value = variables[index].value;
                break;
            }
        }

        if (value == NULL) {
            return -1;
        }

        size_t length = strlen(value);
        if (length >= capacity - used) {
            return -1;
        }

        memcpy(output + used, value, length);
        used += length;
        source = end + 1;
    }

    output[used] = '\0';
    return 0;
}

static int parse_number(
    const char *value,
    unsigned long minimum,
    unsigned long maximum,
    unsigned long *result
) {
    char *end;

    if (*value == '\0' || *value == '-' || *value == '+') {
        return -1;
    }

    errno = 0;
    unsigned long parsed = strtoul(value, &end, 10);
    if (errno != 0 || end == value || *end != '\0' ||
        parsed < minimum || parsed > maximum) {
        return -1;
    }

    *result = parsed;
    return 0;
}

static int set_value(
    log_pool_config *config,
    const char *key,
    const char *value
) {
    unsigned long parsed;
    if (!strcmp(key, "domain")) {
        if (config->domain_count == 16 || !*value || strlen(value) > 253) {
            return -1;
        }
        for (const char *it = value; *it; ++it) {
            if (!isalnum((unsigned char)*it) && *it != '.' && *it != '-') {
                return -1;
            }
        }
        return copy_checked(config->domains[config->domain_count++],
            sizeof(config->domains[0]), value);
    }
    unsigned *flag = NULL;
    if (!strcmp(key, "upnp_legacy_compat")) flag = &config->upnp_legacy_compat;
    if (!strcmp(key, "upnp_allow_permanent")) flag = &config->upnp_allow_permanent;
    if (!strcmp(key, "upnp")) flag = &config->upnp_enabled;
    if (!strcmp(key, "firewall")) flag = &config->firewall_enabled;
    if (!strcmp(key, "smtp_enabled")) flag = &config->smtp_enabled;
    if (!strcmp(key, "dns_enabled")) flag = &config->dns_enabled;
    if (flag != NULL) {
        if (!strcmp(value, "true")) *flag = 1;
        else if (!strcmp(value, "false")) *flag = 0;
        else return -1;
        return 0;
    }

#define CONFIG_STRING(name, member)                                      \
    if (strcmp(key, name) == 0) {                                        \
        return copy_checked(                                            \
            config->member, sizeof(config->member), value              \
        );                                                              \
    }

#define CONFIG_NUMBER(name, member, type, low, high)                           \
    if (strcmp(key, name) == 0) {                                        \
        if (parse_number(value, low, high, &parsed) != 0) {              \
            return -1;                                                  \
        }                                                               \
        config->member = (type)parsed;                               \
        return 0;                                                       \
    }

    CONFIG_STRING("smtp_bind", smtp_bind)
    CONFIG_STRING("smtp_spool", smtp_spool)
    CONFIG_STRING("dns_bind", dns_bind)
    CONFIG_STRING("hostname", hostname)
    CONFIG_STRING("site_title", site_title)
    CONFIG_STRING("site_tagline", site_tagline)
    CONFIG_STRING("http_bind", http_bind)
    CONFIG_STRING("web_root", web_root)
    CONFIG_STRING("log_file", log_file)
    CONFIG_STRING("data_root", data_root)
    CONFIG_STRING("https_bind", https_bind)
    CONFIG_STRING("https_certificate", https_certificate)
    CONFIG_STRING("https_private_key", https_private_key)

    CONFIG_NUMBER("smtp_port", smtp_port, uint16_t, 1, 65535)
    CONFIG_NUMBER("smtp_max_size", smtp_max_size, unsigned, 1024, 26214400)
    CONFIG_NUMBER("dns_port", dns_port, uint16_t, 1, 65535)
    CONFIG_NUMBER("upnp_lease", upnp_lease, unsigned, 600, 86400)
    CONFIG_NUMBER("http_port", http_port, uint16_t, 1, 65535)
    CONFIG_NUMBER("https_port", https_port, uint16_t, 0, 65535)
    CONFIG_NUMBER("max_connections", max_connections, unsigned, 1, 4096)
    CONFIG_NUMBER("idle_timeout", idle_timeout, unsigned, 1, 3600)
    CONFIG_NUMBER("max_per_ip", max_per_ip, unsigned, 1, 1024)
    CONFIG_NUMBER("conn_rate_per_min", conn_rate_per_min, unsigned, 1, 100000)
    CONFIG_NUMBER("session_timeout", session_timeout, unsigned, 1, 86400)

#undef CONFIG_STRING
#undef CONFIG_NUMBER

    /* Unknown options are errors, never silently ignored. */
    return -1;
}

static void default_config(log_pool_config *config) {
    memset(config, 0, sizeof(*config));
    strcpy(config->hostname, "localhost");
    strcpy(config->site_title, "Pool Design Maintenance");
    strcpy(config->site_tagline, "Weave hopeful youth.");
    strcpy(config->http_bind, "127.0.0.1");
    config->http_port = 80;
    config->max_connections = 100;
    config->max_per_ip = 5;
    config->conn_rate_per_min = 30;
    config->idle_timeout = 5;
    config->session_timeout = 1800;
    config->upnp_lease = 3600;
    strcpy(config->smtp_bind, "0.0.0.0");
    strcpy(config->smtp_spool, "Mail/Sshhm/inbox");
    config->smtp_port = 25;
    config->smtp_max_size = 26214400;
    strcpy(config->dns_bind, "127.0.0.1");
    config->dns_port = 53535;
}

static int parse_variable(
    char *line,
    pool_variable *variables,
    size_t *count
) {
    char *name = line + 1;
    char *separator = strchr(name, '=');

    if (separator == NULL || *count == LOG_MAX_VARIABLES) {
        return -1;
    }

    *separator++ = '\0';
    trim(name);
    trim(separator);

    if (*name == '\0' || strlen(name) >= sizeof(variables[0].name)) {
        return -1;
    }

    for (const char *it = name; *it != '\0'; ++it) {
        if (!isalnum((unsigned char)*it) && *it != '_') {
            return -1;
        }
    }

    for (size_t index = 0; index < *count; ++index) {
        if (strcmp(variables[index].name, name) == 0) {
            return -1;
        }
    }

    char expanded[2048];
    if (expand_variables(
            separator, expanded, sizeof(expanded), variables, *count
        ) != 0 ||
        copy_checked(
            variables[*count].value,
            sizeof(variables[*count].value),
            expanded
        ) != 0) {
        return -1;
    }

    strcpy(variables[*count].name, name);
    ++*count;
    return 0;
}

int log_pool_load(
    const char *filename,
    log_pool_config *output,
    char *error,
    size_t capacity
) {
    if (output == NULL || error == NULL || capacity == 0) {
        return -1;
    }

    error[0] = '\0';
    default_config(output);

    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        snprintf(error, capacity, "Cannot open %.180s", filename);
        return -1;
    }

    pool_variable variables[LOG_MAX_VARIABLES] = {0};
    size_t variable_count = 0;
    unsigned line_number = 0;
    char line[2048];
    char expanded[2048];

    while (fgets(line, sizeof(line), file) != NULL) {
        ++line_number;

        if (strchr(line, '\n') == NULL && !feof(file)) {
            snprintf(error, capacity, "line %u: too long", line_number);
            goto fail;
        }

        trim(line);
        if (*line == '\0' || *line == '#') {
            continue;
        }

        if (line[0] == ';' && line[1] != '{') {
            if (parse_variable(line, variables, &variable_count) != 0) {
                snprintf(
                    error, capacity,
                    "line %u: invalid variable", line_number
                );
                goto fail;
            }
            continue;
        }

        char *separator = strpbrk(line, " \t");
        if (separator == NULL) {
            snprintf(
                error, capacity,
                "line %u: missing value", line_number
            );
            goto fail;
        }

        *separator++ = '\0';
        trim(separator);

        if (*separator == '\0' ||
            expand_variables(
                separator, expanded, sizeof(expanded),
                variables, variable_count
            ) != 0 ||
            set_value(output, line, expanded) != 0) {
            snprintf(
                error, capacity,
                "line %u: invalid or unknown setting '%s'",
                line_number,
                line
            );
            goto fail;
        }
    }

    if (ferror(file)) {
        snprintf(error, capacity, "Cannot read configuration");
        goto fail;
    }

    fclose(file);
    return 0;

fail:
    fclose(file);
    return -1;
}
