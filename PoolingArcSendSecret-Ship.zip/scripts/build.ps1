[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string] $NetRoot,
    [switch] $CleanupOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

[Net.ServicePointManager]::SecurityProtocol =
    [Net.SecurityProtocolType]::Tls12

$NetRoot = [IO.Path]::GetFullPath($NetRoot)
$binRoot = Join-Path $NetRoot 'bin'
$cacheRoot = Join-Path $NetRoot '.cache'
$versionRoot = Join-Path $NetRoot '.versions'

$folders = @(
    $NetRoot,
    $binRoot,
    (Join-Path $NetRoot 'include'),
    (Join-Path $NetRoot 'lib'),
    (Join-Path $NetRoot 'share'),
    $cacheRoot,
    $versionRoot
)

foreach ($folder in $folders) {
    New-Item -ItemType Directory -Path $folder -Force |
        Out-Null
}

function Get-Release {
    param([string] $Repository)

    $headers = @{
        'User-Agent' = 'LogOpposingOrbitalPromise-bootstrap'
        'Accept' = 'application/vnd.github+json'
    }

    Invoke-RestMethod `
        -Uri "https://api.github.com/repos/$Repository/releases/latest" `
        -Headers $headers `
        -TimeoutSec 40
}

function Get-Asset {
    param($Release, [string] $Pattern)

    $selected = @(
        $Release.assets |
            Where-Object { $_.name -match $Pattern } |
            Select-Object -First 1
    )

    if ($selected.Count -ne 1) {
        throw "Missing supported archive: $Pattern"
    }

    $selected[0]
}

function Find-ArchiveRoot {
    param(
        [string] $Extraction,
        [string] $ExpectedFile
    )

    $direct = Join-Path $Extraction $ExpectedFile
    if (Test-Path $direct) {
        return $Extraction
    }

    $matches = @(
        Get-ChildItem -LiteralPath $Extraction -Directory |
            Where-Object {
                Test-Path (Join-Path $_.FullName $ExpectedFile)
            }
    )

    if ($matches.Count -ne 1) {
        throw "Unexpected archive layout: $ExpectedFile"
    }

    $matches[0].FullName
}

function Install-Package {
    param(
        [string] $Name,
        $Release,
        $Asset,
        [string] $ArchiveProbe,
        [string] $RequiredFile
    )

    $destination = Join-Path $binRoot $Name
    $record = Join-Path $versionRoot "$Name.txt"
    $identity = "$($Release.tag_name)|$($Asset.name)|$($Asset.size)"

    if ((Test-Path $record) -and
        (Test-Path (Join-Path $destination $RequiredFile))) {
        $installed = (Get-Content -LiteralPath $record -Raw).Trim()
        if ($installed -eq $identity) {
            Write-Host "[SKIP] $Name ($($Release.tag_name)) is current."
            return
        }
    }

    $archive = Join-Path $cacheRoot $Asset.name
    $extraction = Join-Path $cacheRoot "extract-$Name"
    $staging = Join-Path $binRoot "$Name.installing"
    $backup = Join-Path $binRoot "$Name.backup"

    if (-not (Test-Path $archive)) {
        $partial = "$archive.partial"
        if (Test-Path $partial) {
            Remove-Item -LiteralPath $partial -Force
        }

        Write-Host "[GET] $Name $($Release.tag_name)"
        Invoke-WebRequest `
            -Uri $Asset.browser_download_url `
            -OutFile $partial `
            -MaximumRedirection 5 `
            -TimeoutSec 600
        Move-Item -LiteralPath $partial -Destination $archive
    }
    else {
        Write-Host "[CACHE] $($Asset.name)"
    }

    foreach ($item in @($extraction, $staging)) {
        if (Test-Path $item) {
            Remove-Item -LiteralPath $item -Recurse -Force
        }
    }

    Expand-Archive `
        -LiteralPath $archive `
        -DestinationPath $extraction

    $source = Find-ArchiveRoot $extraction $ArchiveProbe
    Copy-Item -LiteralPath $source -Destination $staging -Recurse

    if (-not (Test-Path (Join-Path $staging $RequiredFile))) {
        throw "Incomplete package: $Name/$RequiredFile"
    }

    # Never delete a known-good install before verifying the replacement.
    if (Test-Path $backup) {
        Remove-Item -LiteralPath $backup -Recurse -Force
    }
    if (Test-Path $destination) {
        Move-Item -LiteralPath $destination -Destination $backup
    }

    try {
        Move-Item -LiteralPath $staging -Destination $destination
        [IO.File]::WriteAllText(
            $record,
            $identity + [Environment]::NewLine
        )
    }
    catch {
        if (-not (Test-Path $destination) -and
            (Test-Path $backup)) {
            Move-Item -LiteralPath $backup -Destination $destination
        }
        throw
    }

    if (Test-Path $backup) {
        Remove-Item -LiteralPath $backup -Recurse -Force
    }
    Remove-Item -LiteralPath $extraction -Recurse -Force

    Write-Host "[OK] Installed $Name ($($Release.tag_name))."
}

function Add-DirectoryJunction {
    param(
        [string] $Parent,
        [string] $Package,
        [string] $Source
    )

    $link = Join-Path $Parent $Package
    if ((Test-Path $Source) -and (-not (Test-Path $link))) {
        # A junction avoids duplicating huge toolchain libraries and keeps
        # all files in their vendor-required relative locations.
        New-Item -ItemType Junction -Path $link -Target $Source |
            Out-Null
    }
}

function Get-CachedDownload {
    param([string] $Url, [string] $Name)

    $file = Join-Path $cacheRoot $Name
    if (-not (Test-Path -LiteralPath $file)) {
        Write-Host "[GET] $Name"
        Invoke-WebRequest -Uri $Url -OutFile "$file.partial" `
            -MaximumRedirection 5 -TimeoutSec 1200
        Move-Item -LiteralPath "$file.partial" -Destination $file -Force
    }
    else {
        Write-Host "[CACHE] $Name"
    }
    return $file
}

function Remove-OldSourceBuildTools {
    # Only remove paths created by our previous project bootstrap. Never touch
    # another MSYS installation, Windows configuration, or user profile.
    foreach ($part in @('include', 'lib', 'share')) {
        $link = Join-Path $NetRoot "$part\msys2"
        $item = Get-Item -LiteralPath $link -Force -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                [IO.Directory]::Delete($link)
                Write-Host "[CLEAN] Removed SDK alias $part/msys2"
            }
            else {
                Write-Warning "Leaving unexpected non-junction directory: $link"
            }
        }
    }
    $tree = Join-Path $binRoot 'msys2'
    if (Test-Path -LiteralPath $tree) {
        $item = Get-Item -LiteralPath $tree -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
            throw 'Refusing to recursively clean a redirected MSYS2 directory'
        }
        if (-not (Test-Path (Join-Path $tree 'usr\bin\bash.exe'))) {
            throw "Unrecognized local build tree; inspect manually: $tree"
        }
        # GPG agents may survive the canceled bootstrap's console. Stop
        # only processes executing from this exact local tool tree.
        $ownedPrefix = [IO.Path]::GetFullPath($tree).TrimEnd('\') + '\'
        foreach ($process in (Get-CimInstance Win32_Process)) {
            $executable = $process.ExecutablePath
            if ($executable -and $executable.StartsWith(
                    $ownedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
                Write-Host "[CLEAN] Stopping local build tool PID $($process.ProcessId)"
                Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop
            }
        }
        Remove-Item -LiteralPath $tree -Recurse -Force
        Write-Host '[CLEAN] Removed Net/bin/msys2 including its local home/keyring.'
    }
    $extracted = Join-Path $cacheRoot 'msys2-extract'
    if (Test-Path -LiteralPath $extracted) {
        Remove-Item -LiteralPath $extracted -Recurse -Force
    }
    foreach ($pattern in @('msys2-base-x86_64-*.sfx.exe*', 'openssl-*.zip*')) {
        Get-ChildItem -LiteralPath $cacheRoot -Filter $pattern -File |
            Remove-Item -Force
    }
    $receipt = Join-Path $versionRoot 'msys2-build-tools.txt'
    if (Test-Path -LiteralPath $receipt) {
        Remove-Item -LiteralPath $receipt -Force
    }
    if (Test-Path -LiteralPath '.build') {
        Remove-Item -LiteralPath '.build' -Recurse -Force
        Write-Host '[CLEAN] Removed canceled project build files.'
    }
}

function Install-StaticDependency {
    param(
        [string] $CMakeExecutable,
        [string] $WorkRoot,
        [string] $Package,
        [string[]] $Headers,
        [string[]] $Libraries
    )

    # This is a native MinGW/UCRT binary archive, NOT an MSYS runtime or
    # installer. CMake/libarchive extracts it; no package programs are run.
    # Read the binary repository database instead of scraping its website.
    # This archive contains metadata only; no package manager is installed.
    $repository = 'https://repo.msys2.org/mingw/ucrt64'
    $database = Join-Path $WorkRoot 'ucrt64.db'
    if (-not (Test-Path -LiteralPath $database)) {
        Invoke-WebRequest -UseBasicParsing `
            -Uri "$repository/ucrt64.db" -OutFile $database -TimeoutSec 120
    }
    $entries = @(& $CMakeExecutable -E tar tf $database)
    if ($LASTEXITCODE) { throw 'Cannot list OpenSSL repository index' }
    $descriptions = @($entries | Where-Object {
        $_ -match "^mingw-w64-ucrt-x86_64-$Package-[^/]+/desc$"
    })
    if ($descriptions.Count -ne 1) {
        throw 'Dependency repository entry is missing or ambiguous'
    }
    $metadataRoot = Join-Path $WorkRoot "$Package-metadata"
    New-Item -ItemType Directory -Path $metadataRoot -Force | Out-Null
    Push-Location $metadataRoot
    try {
        & $CMakeExecutable -E tar xf $database $descriptions[0]
        if ($LASTEXITCODE) { throw 'Cannot extract OpenSSL package metadata' }
    }
    finally {
        Pop-Location
    }
    $description = Get-Content `
        (Join-Path $metadataRoot $descriptions[0]) -Raw
    $fileMatch = [regex]::Match(
        $description, '(?m)^%FILENAME%\r?\n([^\r\n]+)'
    )
    $shaMatch = [regex]::Match(
        $description, '(?m)^%SHA256SUM%\r?\n([a-fA-F0-9]{64})'
    )
    if (-not $fileMatch.Success -or -not $shaMatch.Success) {
        throw 'Dependency repository metadata lacks filename/SHA256'
    }
    $name = $fileMatch.Groups[1].Value
    if ($name -notmatch
        "^mingw-w64-ucrt-x86_64-$Package-[0-9A-Za-z.+_-]+\.pkg\.tar\.zst$") {
        throw 'Unexpected OpenSSL package filename'
    }
    $url = "$repository/$name"
    $expectedHash = $shaMatch.Groups[1].Value.ToLowerInvariant()
    $record = Join-Path $versionRoot "$Package-prebuilt.json"
    $includeDir = Join-Path $NetRoot "include\$Package"
    $libraryDir = Join-Path $NetRoot "lib\$Package"
    $shareDir = Join-Path $NetRoot "share\$Package"
    if (Test-Path -LiteralPath $record) {
        $installed = Get-Content $record -Raw | ConvertFrom-Json
        $healthy = ($installed.archive_sha256 -eq $expectedHash) -and
            ($installed.package -eq $name) -and
            (@($installed.files).Count -ge ($Headers.Count + $Libraries.Count))
        foreach ($entry in $installed.files) {
            $path = Join-Path $NetRoot $entry.path
            if (-not (Test-Path -LiteralPath $path)) {
                $healthy = $false
            }
            elseif ((Get-FileHash $path -Algorithm SHA256).Hash -ne $entry.sha256) {
                $healthy = $false
            }
        }
        if ($healthy) {
            Write-Host "[SKIP] Verified static $Package : $name"
            return
        }
    }
    $archive = Get-CachedDownload $url $name
    if ((Get-FileHash $archive -Algorithm SHA256).Hash -ne $expectedHash) {
        Remove-Item -LiteralPath $archive -Force
        throw 'Dependency archive SHA256 mismatch; bad cache file removed'
    }
    $extraction = Join-Path $WorkRoot "$Package-prebuilt"
    New-Item -ItemType Directory -Path $extraction -Force | Out-Null
    Push-Location $extraction
    try {
        & $CMakeExecutable -E tar xf $archive
        if ($LASTEXITCODE) { throw 'Dependency binary archive extraction failed' }
    }
    finally {
        Pop-Location
    }
    $prefix = Join-Path $extraction 'ucrt64'
    $required = @()
    foreach ($header in $Headers) { $required += "include\$Package\$header" }
    foreach ($library in $Libraries) { $required += "lib\$library" }
    foreach ($relative in $required) {
        if (-not (Test-Path (Join-Path $prefix $relative))) {
            throw "$Package archive missing: $relative"
        }
    }
    foreach ($directory in @($includeDir, $libraryDir, $shareDir)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
    Copy-Item (Join-Path $prefix "include\$Package\*.h") $includeDir -Force
    foreach ($library in $Libraries) {
        Copy-Item (Join-Path $prefix "lib\$library") $libraryDir -Force
    }
    $license = Join-Path $prefix "share\licenses\$Package\LICENSE"
    if (-not (Test-Path $license)) {
        throw 'Dependency package license is missing'
    }
    Copy-Item $license (Join-Path $shareDir 'LICENSE.txt') -Force

    # .dll, .dll.a, .exe, manpages and scripts are not installed.
    $files = @()
    $installedFiles = @()
    foreach ($library in $Libraries) {
        $installedFiles += "lib\$Package\$library"
    }
    foreach ($header in (Get-ChildItem $includeDir -Filter '*.h' -File)) {
        $installedFiles += "include\$Package\$($header.Name)"
    }
    foreach ($relative in $installedFiles) {
        $files += @{
            path = $relative
            sha256 = (Get-FileHash (Join-Path $NetRoot $relative)).Hash
        }
    }
    $receipt = @{
        package = $name
        url = $url
        archive_sha256 = $expectedHash
        files = $files
    } | ConvertTo-Json -Depth 4
    [IO.File]::WriteAllText($record, $receipt)
    Remove-Item $extraction -Recurse -Force
    Write-Host "[OK] Static $Package : archives, headers and license installed."
}

function Write-DefaultPoolConfiguration {
    $file = Join-Path $root 'Launch\pool.conf'
    $defaults = [ordered]@{
        hostname = 'delicacy.diy'
        http_bind = '0.0.0.0'
        http_port = '80'
        https_bind = '0.0.0.0'
        https_port = '443'
        https_certificate = '/ssl/LoveShip-chain.pem'
        https_private_key = '/ssl/LoveShip-key.pem'
        upnp = 'true'
        upnp_legacy_compat = 'true'
        upnp_allow_permanent = 'true'
        upnp_lease = '3600'
        firewall = 'true'
        smtp_enabled = 'true'
        smtp_bind = '0.0.0.0'
        smtp_port = '25'
        dns_enabled = 'true'
        dns_bind = '127.0.0.1'
        dns_port = '53535'
    }
    $text = "# PoolingArcSendSecret - only runtime configuration.`r`n"
    if (Test-Path $file) { $text = [IO.File]::ReadAllText($file) }
    foreach ($key in $defaults.Keys) {
        $pattern = '(?m)^' + [regex]::Escape($key) + '[ \t]+[^\r\n]+'
        $line = "$key $($defaults[$key])"
        if ($key -in @('https_certificate', 'https_private_key') -and
            $text -match $pattern) {
            $existing = [regex]::Match($text, $pattern).Value
            $existingValue = ($existing -split '[ \t]+', 2)[1].Trim().Replace('\', '/')
            $oldDefault = if ($key -eq 'https_certificate') {
                '/ssl/LoveVessel-chain.pem'
            } else {
                '/ssl/LoveVessel-key.pem'
            }
            if ($existingValue -ne $oldDefault) { continue }
        }
        if ($text -match $pattern) {
            $text = [regex]::Replace($text, $pattern, $line)
        } else { $text += "`r`n$line" }
    }
    $domains = @('delicacy.diy', 'devilorigin.com', 'lovehive.org',
        'lovelibrary.net', 'reliablereasons.fyi', 'reliablelumen.tech',
        'oasisorder.fun', 'occurance.me')
    if ($text -notmatch '(?m)^domain[ \t]') {
        foreach ($domain in $domains) { $text += "`r`ndomain $domain" }
    }
    $text += "`r`n"
    [IO.File]::WriteAllText($file, $text,
        (New-Object System.Text.UTF8Encoding($false)))
    Write-Host '[OK] Launch/pool.conf: reference domains/TLS and public network settings.'
    Write-Host '[INFO] /ssl prefers Launch/ssl; existing project/parent/drive-root pairs are supported.'
}

function Prepare-TlsFiles {
    $configuration = Join-Path $root 'Launch\pool.conf'
    $values = @{}
    foreach ($line in [IO.File]::ReadAllLines($configuration)) {
        if ($line -match '^\s*(https_certificate|https_private_key)\s+(.+?)\s*$') {
            $values[$matches[1]] = $matches[2]
        }
    }
    $certificate = $values['https_certificate']
    $key = $values['https_private_key']
    if (!$certificate -or !$key) { return }
    # Preserve explicit paths. /ssl is the documented Launch-relative alias.
    if ($certificate -notmatch '^[\\/]ssl[\\/]' -or
        $key -notmatch '^[\\/]ssl[\\/]') { return }
    $certRelative = $certificate.TrimStart([char[]]'\/')
    $keyRelative = $key.TrimStart([char[]]'\/')
    $launch = Join-Path $root 'Launch'
    $destinationCert = Join-Path $launch $certRelative
    $destinationKey = Join-Path $launch $keyRelative
    New-Item -ItemType Directory -Path (Join-Path $launch 'ssl') -Force |
        Out-Null
    if (!(Test-Path -LiteralPath $destinationCert) -and
        !(Test-Path -LiteralPath $destinationKey)) {
        $rootCert = Join-Path $root 'LoveShip-chain.pem'
        $rootKey = Join-Path $root 'LoveShip-key.pem'
        if ($certificate -eq '/ssl/LoveShip-chain.pem' -and
            $key -eq '/ssl/LoveShip-key.pem' -and
            (Test-Path -LiteralPath $rootCert -PathType Leaf) -and
            (Test-Path -LiteralPath $rootKey -PathType Leaf)) {
            $updated = foreach ($line in [IO.File]::ReadAllLines($configuration)) {
                if ($line -match '^https_certificate[ \t]+') {
                    'https_certificate ../LoveShip-chain.pem'
                } elseif ($line -match '^https_private_key[ \t]+') {
                    'https_private_key ../LoveShip-key.pem'
                } else { $line }
            }
            [IO.File]::WriteAllLines($configuration, [string[]]$updated,
                (New-Object System.Text.UTF8Encoding($false)))
            Write-Host '[OK] Using LoveShip certificate/key directly from the project root.'
            return
        }
        $driveRoot = [IO.Path]::GetPathRoot($root)
        $candidates = @($root, (Split-Path $root -Parent), $driveRoot)
        foreach ($base in $candidates) {
            $sourceCert = Join-Path $base $certRelative
            $sourceKey = Join-Path $base $keyRelative
            if ((Test-Path -LiteralPath $sourceCert -PathType Leaf) -and
                (Test-Path -LiteralPath $sourceKey -PathType Leaf)) {
                # Keep private keys in place: runtime uses this same pair
                # through its documented /ssl fallback. No copies in ZIPs.
                Write-Host "[OK] Existing TLS pair found: $sourceCert"
                return
            }
        }
    }
    if (!(Test-Path -LiteralPath $destinationCert -PathType Leaf)) {
        Write-Host "[WARN] TLS certificate missing: $destinationCert" -ForegroundColor Yellow
    }
    if (!(Test-Path -LiteralPath $destinationKey -PathType Leaf)) {
        Write-Host "[WARN] TLS private key missing: $destinationKey" -ForegroundColor Yellow
    }
    Write-Host '[INFO] HTTPS requires an existing matching PEM certificate/key pair.'
}

function Test-ReleaseWritable {
    $release = Join-Path $root 'Launch\PoolingArcSendSecret.exe'
    if (!(Test-Path -LiteralPath $release)) { return }
    try {
        $stream = [IO.File]::Open($release, [IO.FileMode]::Open,
            [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        $stream.Dispose()
    } catch {
        throw 'Existing EXE is locked or not writable. Type exit in the server console, then run log.bat again. The old EXE has NOT been replaced.'
    }
}

function Test-RealTlsFiles {
    $probe = Join-Path $root '.build\tools\log_tls_probe.exe'
    $launch = Join-Path $root 'Launch'
    Push-Location -LiteralPath $launch
    try {
        $details = & $probe 'pool.conf'
        $result = $LASTEXITCODE
        $details | Set-Content -LiteralPath (Join-Path $launch 'tls-check.log')
        foreach ($line in $details) { Write-Host $line }
        if ($result -eq 2) { throw 'Runtime pool.conf could not be loaded; see Launch/tls-check.log' }
        if ($result -ne 0) {
            Write-Host '[WARN] TLS files are not ready. HTTP 80 remains available; accounts require HTTPS.' -ForegroundColor Yellow
            Write-Host '[INFO] Exact TLS diagnostic saved to Launch/tls-check.log.'
        }
    } finally {
        Pop-Location
    }
}

try {
    $root = Split-Path $PSScriptRoot -Parent
    Set-Location -LiteralPath $root
    Remove-OldSourceBuildTools
    if ($CleanupOnly) {
        Write-Host '[OK] Cleanup complete. No downloads or compilation requested.'
        exit 0
    }
    Test-ReleaseWritable
    $ninja = Get-Release 'ninja-build/ninja'
    $ninjaZip = Get-Asset $ninja '^ninja-win\.zip$'
    Install-Package `
        'ninja' $ninja $ninjaZip `
        'ninja.exe' 'ninja.exe'

    # Windows paths are case-insensitive; publish the requested filename.
    $ninjaPath = Join-Path $binRoot 'ninja\ninja.exe'
    if (Test-Path $ninjaPath) {
        Rename-Item -LiteralPath $ninjaPath -NewName 'Ninja.exe' `
            -ErrorAction SilentlyContinue
    }

    $cmake = Get-Release 'Kitware/CMake'
    $cmakeZip = Get-Asset `
        $cmake '^cmake-[0-9.]+-windows-x86_64\.zip$'
    Install-Package `
        'cmake' $cmake $cmakeZip `
        'bin\cmake.exe' 'bin\ctest.exe'

    $llvm = Get-Release 'mstorsjo/llvm-mingw'
    $llvmZip = Get-Asset `
        $llvm '^llvm-mingw-.*-ucrt-x86_64\.zip$'
    Install-Package `
        'llvm-mingw' $llvm $llvmZip `
        'bin\x86_64-w64-mingw32-clang.exe' `
        'bin\x86_64-w64-mingw32-clang.exe'

    foreach ($name in @('cmake', 'llvm-mingw')) {
        foreach ($part in @('include', 'lib', 'share')) {
            $target = Join-Path $binRoot "$name\$part"
            $parent = Join-Path $NetRoot $part
            Add-DirectoryJunction $parent $name $target
        }
    }

    Write-Host '[OK] Windows SDK ready.'

    $root = Split-Path $PSScriptRoot -Parent
    Set-Location -LiteralPath $root
    $llvmBin = Join-Path $NetRoot 'bin\llvm-mingw\bin'
    $cmakeBin = Join-Path $NetRoot 'bin\cmake\bin'
    $cmake = Join-Path $cmakeBin 'cmake.exe'
    $ctest = Join-Path $cmakeBin 'ctest.exe'
    $ninja = Join-Path $NetRoot 'bin\ninja\Ninja.exe'
    $compiler = Join-Path $llvmBin 'x86_64-w64-mingw32-clang.exe'
    $resourceCompiler = Join-Path $llvmBin 'x86_64-w64-mingw32-windres.exe'
    # CMake writes these values into generated CMake source files.
    # Windows backslashes can become invalid escapes (for example \P).
    # Keep native paths for PowerShell/PATH, normalize CMake arguments only.
    $compilerCMake = $compiler.Replace('\', '/')
    $resourceCompilerCMake = $resourceCompiler.Replace('\', '/')
    $ninjaCMake = $ninja.Replace('\', '/')

    $env:PATH = "$llvmBin;$cmakeBin;$env:PATH"
    if (Test-Path '.build') {
        Remove-Item '.build' -Recurse -Force
    }
    New-Item -ItemType Directory -Path '.build' -Force | Out-Null
    $workRoot = Join-Path $root '.build'
    Install-StaticDependency $cmake $workRoot 'openssl' `
        @('ssl.h', 'opensslconf.h') @('libssl.a', 'libcrypto.a')
    Install-StaticDependency $cmake $workRoot 'miniupnpc' `
        @('miniupnpc.h', 'upnpcommands.h') @('libminiupnpc.a')
    $sdkCMake = $NetRoot.Replace('\', '/')
    & $cmake -S . -B .build -G Ninja `
        '-DCMAKE_BUILD_TYPE=Release' `
        "-DLOG_SDK_DIR:PATH=$sdkCMake" `
        "-DCMAKE_C_COMPILER:FILEPATH=$compilerCMake" `
        "-DCMAKE_RC_COMPILER:FILEPATH=$resourceCompilerCMake" `
        "-DCMAKE_MAKE_PROGRAM:FILEPATH=$ninjaCMake" `
        '-DCMAKE_SUPPRESS_REGENERATION=ON'
    if ($LASTEXITCODE) { throw 'CMake configuration failed' }
    & $cmake --build .build
    if ($LASTEXITCODE) { throw 'Compilation failed' }
    & $ctest --test-dir .build --output-on-failure
    if ($LASTEXITCODE) { throw 'Tests failed' }
    $built = '.build\out\PoolingArcSendSecret.exe'
    $readobj = Join-Path $llvmBin 'llvm-readobj.exe'
    $imports = & $readobj --coff-imports $built
    if ($LASTEXITCODE) { throw 'Could not inspect EXE imports' }
    $imports | Set-Content '.build\imports.txt'
    if (($imports -join "`n") -match
        '(?i)Name:.*(libssl|libcrypto|libminiupnpc|libwinpthread|libgcc_s|msys-2.0).*\.dll') {
        throw 'Unexpected dependency DLL: static-link verification failed'
    }
    New-Item -ItemType Directory -Path Launch -Force | Out-Null
    Write-DefaultPoolConfiguration
    Prepare-TlsFiles
    Test-RealTlsFiles
    $obsolete = Join-Path $root 'pool.conf'
    if (Test-Path -LiteralPath $obsolete) {
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
        Move-Item -LiteralPath $obsolete `
            -Destination "$obsolete.$stamp.legacy-backup"
        Write-Host '[INFO] Obsolete root config archived; using Launch/pool.conf.'
    }
    $site = Join-Path $root 'Launch\entry'
    New-Item -ItemType Directory -Path $site -Force | Out-Null
    foreach ($asset in @(
        'index.html',
        'maintenance.html',
        'institute.html',
        'account.html',
        'go-live.html',
        'mail.html',
        'media.js',
        'mail.js',
        'design.css',
        'design.js',
        'honeycomb.svg',
        'mirror-logo.png'
    )) {
        Copy-Item (Join-Path $root "entry\$asset") $site -Force
    }
    $media = Join-Path $root 'Launch\Media'
    New-Item -ItemType Directory -Path $media -Force | Out-Null
    Copy-Item (Join-Path $root 'Media\index.html') $media -Force
    $exe = 'PoolingArcSendSecret.exe'  
    Copy-Item ".build\out\$exe" "Launch\$exe.next" -Force
    Move-Item "Launch\$exe.next" "Launch\$exe" -Force
    Remove-Item '.build' -Recurse -Force
    Write-Host "[OK] Version 0.1.5 published: $root\Launch\$exe"
    Write-Host "[OK] Double-click Launch\$exe to run the server."
    exit 0
}
catch {
    $message = [regex]::Replace($_.Exception.Message, '\s+', ' ')
    if ($message.Length -gt 400) {
        $message = $message.Substring(0, 400) + '...'
    }
    Write-Host "[ERROR] Build failed: $message" -ForegroundColor Red
    exit 1
}
