'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync('entry/design.js','utf8');
const snippet = source.slice(source.indexOf('const themes = ['),
  source.indexOf('function returnPath()'));
function verify(saved, expected, blocked = false) {
  const elements = new Map(), properties = new Map(), stored = new Map([['pool.textSize',saved]]);
  const element = id => {
    if (!elements.has(id)) elements.set(id, {
      value:'', options:[], listeners:{},
      replaceChildren(...options) { this.options=options; },
      addEventListener(name,fn) { this.listeners[name]=fn; }
    });
    return elements.get(id);
  };
  const context = {
    $:element,
    renderTemplate(id, fields) {
      const option={label:fields.label,value:''};
      return {option,querySelector() { return option; }};
    },
    document:{documentElement:{style:{setProperty(k,v) { properties.set(k,v); }}}},
    localStorage:{
      getItem(key) { if(blocked)throw new Error('Storage blocked');return stored.get(key); },
      setItem(key,value) { if(blocked)throw new Error('Storage blocked');stored.set(key,value); }
    }
  };
  vm.runInNewContext(snippet,context);
  const selector=element('text-size-select');
  assert.equal(selector.options.length,13);
  assert.equal(selector.options[0].option.value,'8');
  assert.equal(selector.options[12].option.value,'20');
  assert.equal(selector.value,expected);
  assert.equal(properties.get('--text-size'),`${expected}px`);
  selector.value='20';selector.listeners.change();
  assert.equal(properties.get('--text-size'),'20px');
  if(!blocked)assert.equal(stored.get('pool.textSize'),'20');
}
verify('17','17');verify('200','13');verify('12','13',true);
console.log('Text-size options, saved size, invalid preferences and blocked storage passed');
