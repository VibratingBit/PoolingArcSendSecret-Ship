#include "http.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

static bool token_char(unsigned char character) {
    return character != 0 && (isalnum(character) ||
           strchr("!#$%&'*+-.^_`|~", character) != NULL);
}

static char *find_bytes(
    char *data,
    size_t size,
    const char *needle,
    size_t needle_size
) {
    if (size < needle_size) {
        return NULL;
    }

    for (size_t index = 0; index <= size - needle_size; ++index) {
        if (memcmp(data + index, needle, needle_size) == 0) {
            return data + index;
        }
    }

    return NULL;
}

int log_http_parse(
    char *data,
    size_t length,
    log_request *out
) {
    char *headers_end;
    char *request_end;
    char *space1;
    char *space2;
    char *cursor;
    size_t header_length;
    size_t method_length;
    size_t path_length;
    size_t content_length = 0;
    int host_count = 0;
    int length_count = 0;

    if (data == NULL || out == NULL || length == 0 ||
        length > LOG_MAX_REQUEST + LOG_MAX_BODY) {
        return 400;
    }

    memset(out, 0, sizeof(*out));
    headers_end = find_bytes(data, length, "\r\n\r\n", 4);

    if (headers_end == NULL) {
        return 400;
    }

    headers_end += 4;
    header_length = (size_t)(headers_end - data);

    if (header_length > LOG_MAX_REQUEST) {
        return 431;
    }

    request_end = find_bytes(data, header_length, "\r\n", 2);
    if (request_end == NULL) {
        return 400;
    }

    space1 = memchr(data, ' ', (size_t)(request_end - data));
    if (space1 == NULL) {
        return 400;
    }

    space2 = memchr(
        space1 + 1,
        ' ',
        (size_t)(request_end - space1 - 1)
    );

    if (space2 == NULL) {
        return 400;
    }

    method_length = (size_t)(space1 - data);
    path_length = (size_t)(space2 - space1 - 1);

    if (method_length == 0 || method_length >= sizeof(out->method) ||
        path_length == 0 || path_length >= sizeof(out->path)) {
        return 400;
    }

    if (space1[1] != '/' || request_end - space2 != 9 ||
        (memcmp(space2 + 1, "HTTP/1.1", 8) != 0 &&
         memcmp(space2 + 1, "HTTP/1.0", 8) != 0)) {
        return 400;
    }

    for (char *it = data; it < space1; ++it) {
        if (!token_char((unsigned char)*it)) {
            return 400;
        }
    }

    for (char *it = space1 + 1; it < space2; ++it) {
        unsigned char value = (unsigned char)*it;
        if (value <= 32 || value >= 127 || value == '#') {
            return 400;
        }
    }

    memcpy(out->method, data, method_length);
    out->method[method_length] = '\0';
    memcpy(out->path, space1 + 1, path_length);
    out->path[path_length] = '\0';

    cursor = request_end + 2;

    while (cursor < headers_end - 2) {
        char *line_end = find_bytes(
            cursor,
            (size_t)(headers_end - cursor),
            "\r\n",
            2
        );

        if (line_end == NULL || line_end == cursor) {
            return 400;
        }

        char *colon = memchr(
            cursor,
            ':',
            (size_t)(line_end - cursor)
        );

        if (colon == NULL || colon == cursor) {
            return 400;
        }

        for (char *it = cursor; it < colon; ++it) {
            if (!token_char((unsigned char)*it)) {
                return 400;
            }
        }

        for (char *it = colon + 1; it < line_end; ++it) {
            unsigned char value = (unsigned char)*it;
            if ((value < 32 && value != '\t') || value == 127) {
                return 400;
            }
        }

        size_t name_length = (size_t)(colon - cursor);
        char *value = colon + 1;

        while (value < line_end &&
               (*value == ' ' || *value == '\t')) {
            ++value;
        }

        char *trimmed_end = line_end;
        while (trimmed_end > value &&
            (trimmed_end[-1] == ' ' || trimmed_end[-1] == '\t')) --trimmed_end;
        char *destination = NULL;
        size_t capacity = 0;
#define HEADER(name, field) \
        if (name_length == sizeof(name) - 1 && \
            !_strnicmp(cursor, name, sizeof(name) - 1)) { \
            destination = out->field; capacity = sizeof(out->field); \
        }
        HEADER("Host", host)
        HEADER("Origin", origin)
        HEADER("Range", range)
        HEADER("Cookie", cookie)
        HEADER("X-CSRF-Token", csrf)
#undef HEADER
        if (destination != NULL) {
            size_t size = (size_t)(trimmed_end - value);
            if (size >= capacity || destination[0]) return 400;
            memcpy(destination, value, size);
            destination[size] = 0;
        }
        if (name_length == 4 &&
            _strnicmp(cursor, "Host", 4) == 0) {
            if (++host_count > 1 || value == line_end) {
                return 400;
            }
        } else if (name_length == 14 &&
                   _strnicmp(cursor, "Content-Length", 14) == 0) {
            if (++length_count > 1 || value == line_end) {
                return 400;
            }

            for (; value < line_end; ++value) {
                if (*value < '0' || *value > '9') {
                    return 400;
                }

                unsigned digit = (unsigned)(*value - '0');
                if (content_length > (LOG_MAX_BODY - digit) / 10) {
                    return 413;
                }

                content_length = content_length * 10 + digit;
            }
        } else if (name_length == 17 &&
                   _strnicmp(cursor, "Transfer-Encoding", 17) == 0) {
            /* Do not accept ambiguous request-body framing. */
            return 501;
        }

        cursor = line_end + 2;
    }

    if (memcmp(space2 + 1, "HTTP/1.1", 8) == 0 &&
        host_count != 1) {
        return 400;
    }

    if (length - header_length != content_length) {
        return 400;
    }

    out->body = headers_end;
    out->body_length = content_length;
    return 0;
}

const char *log_http_reason(int status) {
    switch (status) {
        case 206: return "Partial Content";
        case 416: return "Range Not Satisfiable";
        case 502: return "Bad Gateway";
        case 507: return "Insufficient Storage";
        case 200: return "OK";
        case 201: return "Created";
        case 202: return "Accepted";
        case 503: return "Service Unavailable";
        case 308: return "Permanent Redirect";
        case 400: return "Bad Request";
        case 401: return "Unauthorized";
        case 403: return "Forbidden";
        case 409: return "Conflict";
        case 426: return "Upgrade Required";
        case 429: return "Too Many Requests";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 413: return "Content Too Large";
        case 431: return "Request Header Fields Too Large";
        case 500: return "Internal Server Error";
        case 501: return "Not Implemented";
        default: return "Error";
    }
}
