#ifndef LOG_FORM_H
#define LOG_FORM_H
#include <stddef.h>
int log_form_get(const char *body, size_t length, const char *name,
    char *output, size_t capacity);
#endif
