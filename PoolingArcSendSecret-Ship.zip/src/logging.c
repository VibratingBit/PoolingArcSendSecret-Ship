#include "logging.h"
#include "entry.h"
#include "terminal.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LOG_ROWS 1024
#define LOG_TEXT 512

typedef struct {
    char text[LOG_TEXT];
    WORD color;
} console_row;

static SRWLOCK output_lock = SRWLOCK_INIT;
static volatile LONG access_enabled = 1;
static console_row rows[LOG_ROWS];
static unsigned long long total;
static unsigned count;
static unsigned scroll_offset;
static HANDLE input_handle;
static HANDLE output_handle;
static DWORD original_input_mode;
static CONSOLE_CURSOR_INFO original_cursor;
static bool terminal_active;
static bool following = true;

void log_access_enabled(bool enabled) {
    InterlockedExchange(&access_enabled, enabled ? 1 : 0);
}

bool log_access_is_enabled(void) {
    return InterlockedCompareExchange(&access_enabled, 0, 0) != 0;
}

static WORD category_color(const char *category) {
    if (!strcmp(category, "ERROR")) return 12;
    if (!strcmp(category, "HTTP")) return 10;
    if (!strcmp(category, "TLS")) return 13;
    if (!strcmp(category, "CONFIG")) return 14;
    if (!strcmp(category, "SERVER")) return 11;
    return 7;
}

void log_write(const char *category, const char *format, ...) {
    SYSTEMTIME now;
    char text[LOG_TEXT];
    va_list arguments;
    GetLocalTime(&now);
    int prefix = snprintf(text, sizeof(text), "[%02u:%02u:%02u] [%s] ",
        (unsigned)now.wHour, (unsigned)now.wMinute,
        (unsigned)now.wSecond, category);
    if (prefix < 0 || prefix >= (int)sizeof(text)) return;
    va_start(arguments, format);
    vsnprintf(text + prefix, sizeof(text) - (size_t)prefix, format, arguments);
    va_end(arguments);
    /* Never let network-controlled text inject terminal control sequences. */
    for (char *it = text; *it; ++it) {
        if ((unsigned char)*it < 32 || *it == 127) *it = ' ';
    }
    AcquireSRWLockExclusive(&output_lock);
    console_row *row = &rows[total % LOG_ROWS];
    strcpy(row->text, text);
    row->color = category_color(category);
    ++total;
    if (count < LOG_ROWS) ++count;
    if (!following && scroll_offset < count - 1) ++scroll_offset;
    if (!terminal_active) {
        puts(text);
        fflush(stdout);
    }
    ReleaseSRWLockExclusive(&output_lock);
}

void log_terminal_init(void) {
    input_handle = GetStdHandle(STD_INPUT_HANDLE);
    output_handle = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode;
    if (!GetConsoleMode(input_handle, &original_input_mode) ||
        !GetConsoleMode(output_handle, &mode)) return;
    if (!GetConsoleCursorInfo(output_handle, &original_cursor)) return;
    DWORD input_mode = ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT |
        ENABLE_MOUSE_INPUT;
    if (!SetConsoleMode(input_handle, input_mode)) return;
    terminal_active = true;
    HWND console_window = GetConsoleWindow();
    HICON icon = LoadIconW(GetModuleHandleW(NULL), MAKEINTRESOURCEW(2));
    if (console_window != NULL && icon != NULL) {
        SendMessageW(console_window, WM_SETICON, ICON_BIG, (LPARAM)icon);
        SendMessageW(console_window, WM_SETICON, ICON_SMALL, (LPARAM)icon);
    }
}

void log_terminal_close(void) {
    if (!terminal_active) return;
    terminal_active = false;
    SetConsoleMode(input_handle, original_input_mode);
    SetConsoleCursorInfo(output_handle, &original_cursor);
    SetConsoleTextAttribute(output_handle, 7);
}

void log_terminal_wipe(void) {
    AcquireSRWLockExclusive(&output_lock);
    memset(rows, 0, sizeof(rows));
    total = 0;
    count = 0;
    scroll_offset = 0;
    following = true;
    ReleaseSRWLockExclusive(&output_lock);
}

static void paint_text(
    CHAR_INFO *screen, int width, int height,
    int row, const char *text, WORD color
) {
    if (row < 0 || row >= height) return;
    for (int x = 0; x < width && text[x]; ++x) {
        screen[row * width + x].Char.AsciiChar = text[x];
        screen[row * width + x].Attributes = color;
    }
}

static void render(const char *command, size_t cursor) {
    CONSOLE_SCREEN_BUFFER_INFO info;
    if (!GetConsoleScreenBufferInfo(output_handle, &info)) return;
    int width = info.srWindow.Right - info.srWindow.Left + 1;
    int height = info.srWindow.Bottom - info.srWindow.Top + 1;
    if (width < 20 || height < 9 || width > 1000 || height > 1000) return;
    CHAR_INFO *screen = calloc((size_t)width * (size_t)height, sizeof(*screen));
    if (screen == NULL) return;
    for (int i = 0; i < width * height; ++i) {
        screen[i].Char.AsciiChar = ' ';
        screen[i].Attributes = 7;
    }
    paint_text(screen, width, height, 0,
        " POOLING ARC SEND SECRET | " LOG_VERSION, 11);
    paint_text(screen, width, height, 1,
        " help | status | traffic | start | shutdown | reload | /wipe | exit", 8);
    size_t available = (size_t)(width - 8);
    size_t start = cursor > available ? cursor - available : 0;
    char prompt[300];
    snprintf(prompt, sizeof(prompt), "pool> %s", command + start);
    paint_text(screen, width, height, 3, prompt, 15);
    paint_text(screen, width, height, 5,
        " LIVE LOGS | mouse wheel / PgUp / PgDn | Ctrl+End follows newest", 14);
    AcquireSRWLockShared(&output_lock);
    unsigned visible = (unsigned)(height - 7);
    unsigned offset = scroll_offset < count ? scroll_offset : count;
    unsigned amount = count - offset;
    if (amount > visible) amount = visible;
    unsigned long long first = total - offset - amount;
    for (unsigned line = 0; line < amount; ++line) {
        const console_row *entry = &rows[(first + line) % LOG_ROWS];
        paint_text(screen, width, height, 6 + (int)line,
            entry->text, entry->color);
    }
    char footer[120];
    snprintf(footer, sizeof(footer),
        " %s | %u buffered lines | %u lines back | /wipe clears view only",
        following ? "FOLLOWING LIVE" : "SCROLLING HISTORY", count, offset);
    paint_text(screen, width, height, height - 1, footer, 8);
    ReleaseSRWLockShared(&output_lock);
    COORD dimensions = {(SHORT)width, (SHORT)height};
    COORD origin = {0, 0};
    SMALL_RECT region = info.srWindow;
    WriteConsoleOutputA(output_handle, screen, dimensions, origin, &region);
    COORD position = {
        (SHORT)(info.srWindow.Left + 6 + (int)(cursor - start)),
        (SHORT)(info.srWindow.Top + 3)
    };
    SetConsoleCursorPosition(output_handle, position);
    free(screen);
}

static void scroll_logs(int delta) {
    AcquireSRWLockExclusive(&output_lock);
    int next = (int)scroll_offset + delta;
    if (next < 0) next = 0;
    if (count == 0) next = 0;
    else if (next > (int)count - 1) next = (int)count - 1;
    scroll_offset = (unsigned)next;
    following = scroll_offset == 0;
    ReleaseSRWLockExclusive(&output_lock);
}

bool log_terminal_read(char *command, size_t capacity) {
    if (!terminal_active) {
        fputs("pool> ", stdout);
        if (fgets(command, (int)capacity, stdin) == NULL) return false;
        if (strchr(command, '\n') == NULL && !feof(stdin)) {
            int character;
            while ((character = getchar()) != '\n' && character != EOF) {}
            command[0] = '\0';
            log_write("COMMAND", "Overlong input discarded.");
        }
        return true;
    }
    if (capacity == 0) return false;
    command[0] = '\0';
    size_t length = 0;
    size_t cursor = 0;
    for (;;) {
        render(command, cursor);
        if (WaitForSingleObject(input_handle, 100) != WAIT_OBJECT_0) continue;
        INPUT_RECORD event;
        DWORD received;
        if (!ReadConsoleInputW(input_handle, &event, 1, &received)) return false;
        if (event.EventType == MOUSE_EVENT &&
            event.Event.MouseEvent.dwEventFlags == MOUSE_WHEELED) {
            SHORT wheel = (SHORT)HIWORD(event.Event.MouseEvent.dwButtonState);
            scroll_logs(wheel > 0 ? 3 : -3);
        }
        if (event.EventType != KEY_EVENT || !event.Event.KeyEvent.bKeyDown) {
            continue;
        }
        KEY_EVENT_RECORD key = event.Event.KeyEvent;
        bool control = (key.dwControlKeyState &
            (LEFT_CTRL_PRESSED | RIGHT_CTRL_PRESSED)) != 0;
        if (control && key.wVirtualKeyCode == 'C') {
            strcpy(command, "exit");
            return true;
        }
        if (key.wVirtualKeyCode == VK_PRIOR) { scroll_logs(10); continue; }
        if (key.wVirtualKeyCode == VK_NEXT) { scroll_logs(-10); continue; }
        if (control && key.wVirtualKeyCode == VK_END) {
            scroll_logs(-LOG_ROWS);
            continue;
        }
        if (key.wVirtualKeyCode == VK_RETURN) return true;
        if (key.wVirtualKeyCode == VK_LEFT && cursor > 0) { --cursor; continue; }
        if (key.wVirtualKeyCode == VK_RIGHT && cursor < length) {
            ++cursor;
            continue;
        }
        if (key.wVirtualKeyCode == VK_HOME) { cursor = 0; continue; }
        if (key.wVirtualKeyCode == VK_END) { cursor = length; continue; }
        if (key.wVirtualKeyCode == VK_BACK && cursor > 0) {
            memmove(command + cursor - 1, command + cursor, length - cursor + 1);
            --cursor;
            --length;
            continue;
        }
        if (key.wVirtualKeyCode == VK_DELETE && cursor < length) {
            memmove(command + cursor, command + cursor + 1, length - cursor);
            --length;
            continue;
        }
        wchar_t character = key.uChar.UnicodeChar;
        if (!control && character >= 32 && character < 127 &&
            length + 1 < capacity) {
            memmove(command + cursor + 1, command + cursor, length - cursor + 1);
            command[cursor++] = (char)character;
            ++length;
        }
    }
}
