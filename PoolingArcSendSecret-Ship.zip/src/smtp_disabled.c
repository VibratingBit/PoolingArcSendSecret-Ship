#include "smtp.h"
#include "logging.h"
bool log_smtp_start(const log_pool_config *config) {
    if (config->smtp_enabled) log_write("SMTP", "Not compiled into this build");
    return !config->smtp_enabled;
}
void log_smtp_stop(void) {
}
bool log_smtp_running(void) {
    return false;
}
